const API_BASE = 'http://localhost:3001/api';

// Simple storage for token
let authToken: string | null = null;

export const setAuthToken = (token: string) => {
  authToken = token;
};

export const getAuthToken = () => {
  return authToken;
};

export const api = {
  async request(endpoint: string, options: any = {}) {
    const url = `${API_BASE}${endpoint}`;
    
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    // Add auth token if available
    if (authToken) {
      config.headers.Authorization = `Bearer ${authToken}`;
    }

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API request failed');
    }
    
    return response.json();
  },

  async signUp(userData: any) {
    const result = await this.request('/signup', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    setAuthToken(result.token);
    return result;
  },

  async login(credentials: any) {
    const result = await this.request('/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    setAuthToken(result.token);
    return result;
  },

  async getCurrentUser() {
    return this.request('/user');
  },
};