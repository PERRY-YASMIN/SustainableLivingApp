import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { api } from './utils/api';

export default function SignUpScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    campus: 'Karunya University',
  });
  const [loading, setLoading] = useState(false);

  const handleSignUp = async () => {
    if (!formData.name || !formData.email || !formData.password || !formData.campus) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    setLoading(true);
    try {
      await api.signUp(formData);
      Alert.alert('Success', 'Account created successfully!');
      router.push('/onboarding');
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d', padding: 20 }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{ alignItems: 'center', marginTop: 60, marginBottom: 40 }}>
          <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#4CAF50', marginBottom: 10 }}>EcoCampus</Text>
          <Text style={{ color: 'white', fontSize: 16 }}>Create Your Account</Text>
        </View>

        <View style={{ backgroundColor: 'rgba(255,255,255,0.95)', padding: 25, borderRadius: 20 }}>
          <TextInput
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 15,
              borderWidth: 1,
              borderColor: '#ddd',
            }}
            placeholder="Full Name *"
            value={formData.name}
            onChangeText={(text) => setFormData({...formData, name: text})}
          />

          <TextInput
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 15,
              borderWidth: 1,
              borderColor: '#ddd',
            }}
            placeholder="Email Address *"
            keyboardType="email-address"
            autoCapitalize="none"
            value={formData.email}
            onChangeText={(text) => setFormData({...formData, email: text})}
          />

          <TextInput
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 15,
              borderWidth: 1,
              borderColor: '#ddd',
            }}
            placeholder="Password *"
            secureTextEntry
            value={formData.password}
            onChangeText={(text) => setFormData({...formData, password: text})}
          />

          <TextInput
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 25,
              borderWidth: 1,
              borderColor: '#ddd',
            }}
            placeholder="Campus *"
            value={formData.campus}
            onChangeText={(text) => setFormData({...formData, campus: text})}
          />

          <TouchableOpacity 
            onPress={handleSignUp}
            disabled={loading}
            style={{
              backgroundColor: loading ? '#cccccc' : '#4CAF50',
              padding: 15,
              borderRadius: 10,
              alignItems: 'center',
            }}
          >
            <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>
              {loading ? 'Creating Account...' : 'Create Account'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            onPress={() => router.push('/login')}
            style={{ alignItems: 'center', marginTop: 15 }}
          >
            <Text style={{ color: '#4CAF50', fontWeight: '500' }}>
              Already have an account? Sign In
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}