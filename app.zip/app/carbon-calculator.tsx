import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function CarbonCalculatorScreen() {
  const router = useRouter();
  const [transportation, setTransportation] = useState('');
  const [energy, setEnergy] = useState('');
  const [food, setFood] = useState('');
  const [waste, setWaste] = useState('');
  const [result, setResult] = useState<number | null>(null);
  const [tips, setTips] = useState<string[]>([]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const calculateCarbon = () => {
    const transportCO2 = parseFloat(transportation) * 0.21 || 0;
    const energyCO2 = parseFloat(energy) * 0.52 || 0;
    const foodCO2 = parseFloat(food) * 1.8 || 0;
    const wasteCO2 = parseFloat(waste) * 0.35 || 0;
    
    const totalCO2 = transportCO2 + energyCO2 + foodCO2 + wasteCO2;
    setResult(totalCO2);

    // Generate personalized tips
    const newTips = [];
    if (transportCO2 > 2) newTips.push('🚗 Try carpooling or public transport 2x/week');
    if (energyCO2 > 3) newTips.push('💡 Switch to LED bulbs and unplug devices when not in use');
    if (foodCO2 > 4) newTips.push('🌱 Have 3 meat-free days this week');
    if (wasteCO2 > 1) newTips.push('♻️ Start composting food waste');
    if (totalCO2 < 5) newTips.push('🎉 Amazing! You\'re already eco-friendly!');
    
    setTips(newTips.slice(0, 3));
  };

  const quickCalculate = (activity: string) => {
    const calculations: any = {
      'bus': { transport: '10', energy: '0', food: '0', waste: '0' },
      'bike': { transport: '0', energy: '0', food: '0', waste: '0' },
      'vegan': { transport: '0', energy: '0', food: '2', waste: '0' },
      'solar': { transport: '0', energy: '1', food: '0', waste: '0' }
    };

    const calc = calculations[activity];
    setTransportation(calc.transport);
    setEnergy(calc.energy);
    setFood(calc.food);
    setWaste(calc.waste);
    
    setTimeout(calculateCarbon, 500);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      {/* Header */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        paddingTop: 60,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#4CAF50' }}>Carbon Calculator</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 20 }} showsVerticalScrollIndicator={false}>
        <Animated.View style={{ 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}>
          {/* Quick Actions */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Quick Calculate</Text>
            <Text style={{ color: '#666', marginBottom: 15 }}>See the impact of common eco-actions</Text>
            
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
              <TouchableOpacity 
                style={{ backgroundColor: '#4CAF50', padding: 15, borderRadius: 12, width: '48%', marginBottom: 10 }}
                onPress={() => quickCalculate('bus')}
              >
                <View style={{ alignItems: 'center' }}>
                  <Ionicons name="bus" size={24} color="white" />
                  <Text style={{ color: 'white', fontWeight: 'bold', marginTop: 5, fontSize: 12 }}>Bus Commute</Text>
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={{ backgroundColor: '#2196F3', padding: 15, borderRadius: 12, width: '48%', marginBottom: 10 }}
                onPress={() => quickCalculate('bike')}
              >
                <View style={{ alignItems: 'center' }}>
                  <Ionicons name="bicycle" size={24} color="white" />
                  <Text style={{ color: 'white', fontWeight: 'bold', marginTop: 5, fontSize: 12 }}>Bike to Work</Text>
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={{ backgroundColor: '#FF9800', padding: 15, borderRadius: 12, width: '48%', marginBottom: 10 }}
                onPress={() => quickCalculate('vegan')}
              >
                <View style={{ alignItems: 'center' }}>
                  <Ionicons name="leaf" size={24} color="white" />
                  <Text style={{ color: 'white', fontWeight: 'bold', marginTop: 5, fontSize: 12 }}>Vegan Day</Text>
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={{ backgroundColor: '#9C27B0', padding: 15, borderRadius: 12, width: '48%', marginBottom: 10 }}
                onPress={() => quickCalculate('solar')}
              >
                <View style={{ alignItems: 'center' }}>
                  <Ionicons name="sunny" size={24} color="white" />
                  <Text style={{ color: 'white', fontWeight: 'bold', marginTop: 5, fontSize: 12 }}>Solar Energy</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {/* Detailed Calculator */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20, color: '#1a1a1a' }}>Detailed Calculation</Text>
            
            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontWeight: '600', marginBottom: 8, color: '#333', fontSize: 16 }}>🚗 Distance traveled (km)</Text>
              <TextInput
                style={{ 
                  borderWidth: 2, 
                  borderColor: '#e0e0e0', 
                  borderRadius: 12, 
                  padding: 15,
                  fontSize: 16,
                  backgroundColor: '#f8f9fa',
                }}
                placeholder="e.g., 10 km"
                keyboardType="numeric"
                value={transportation}
                onChangeText={setTransportation}
              />
            </View>
            
            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontWeight: '600', marginBottom: 8, color: '#333', fontSize: 16 }}>⚡ Energy used (kWh)</Text>
              <TextInput
                style={{ 
                  borderWidth: 2, 
                  borderColor: '#e0e0e0', 
                  borderRadius: 12, 
                  padding: 15,
                  fontSize: 16,
                  backgroundColor: '#f8f9fa',
                }}
                placeholder="e.g., 5 kWh"
                keyboardType="numeric"
                value={energy}
                onChangeText={setEnergy}
              />
            </View>
            
            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontWeight: '600', marginBottom: 8, color: '#333', fontSize: 16 }}>🍽️ Meat meals this week</Text>
              <TextInput
                style={{ 
                  borderWidth: 2, 
                  borderColor: '#e0e0e0', 
                  borderRadius: 12, 
                  padding: 15,
                  fontSize: 16,
                  backgroundColor: '#f8f9fa',
                }}
                placeholder="e.g., 3 meals"
                keyboardType="numeric"
                value={food}
                onChangeText={setFood}
              />
            </View>

            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontWeight: '600', marginBottom: 8, color: '#333', fontSize: 16 }}>🗑️ Waste produced (kg)</Text>
              <TextInput
                style={{ 
                  borderWidth: 2, 
                  borderColor: '#e0e0e0', 
                  borderRadius: 12, 
                  padding: 15,
                  fontSize: 16,
                  backgroundColor: '#f8f9fa',
                }}
                placeholder="e.g., 2 kg"
                keyboardType="numeric"
                value={waste}
                onChangeText={setWaste}
              />
            </View>

            <TouchableOpacity 
              style={{ 
                backgroundColor: '#4CAF50', 
                padding: 18, 
                borderRadius: 12, 
                marginBottom: 20,
                shadowColor: '#4CAF50',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.4,
                shadowRadius: 12,
                elevation: 8,
              }}
              onPress={calculateCarbon}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', fontSize: 18 }}>
                Calculate CO₂ Emissions
              </Text>
            </TouchableOpacity>

            {result !== null && (
              <View style={{ backgroundColor: '#E8F5E8', padding: 20, borderRadius: 15, marginBottom: 20 }}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#2E7D32', textAlign: 'center', marginBottom: 10 }}>
                  Your Carbon Footprint: {result.toFixed(2)} kg CO₂
                </Text>
                <Text style={{ color: '#4CAF50', textAlign: 'center', fontSize: 14 }}>
                  {result < 5 ? '🌱 Eco Champion!' : result < 10 ? '💚 Good job!' : '📈 Room for improvement!'}
                </Text>
                
                {/* Carbon Comparison */}
                <View style={{ marginTop: 15, padding: 15, backgroundColor: 'rgba(76, 175, 80, 0.1)', borderRadius: 10 }}>
                  <Text style={{ fontWeight: 'bold', color: '#2E7D32', marginBottom: 8 }}>Equivalent to:</Text>
                  <Text style={{ color: '#4CAF50', fontSize: 12 }}>• {Math.round(result / 0.4)} km of driving</Text>
                  <Text style={{ color: '#4CAF50', fontSize: 12 }}>• {Math.round(result / 21)} trees needed to absorb</Text>
                  <Text style={{ color: '#4CAF50', fontSize: 12 }}>• {Math.round(result * 12)} kWh of electricity</Text>
                </View>
              </View>
            )}

            {tips.length > 0 && (
              <View style={{ backgroundColor: '#FFF3E0', padding: 20, borderRadius: 15 }}>
                <Text style={{ fontWeight: 'bold', color: '#FF9800', marginBottom: 10, fontSize: 16 }}>💡 Personalized Tips</Text>
                {tips.map((tip, index) => (
                  <Text key={index} style={{ color: '#666', marginBottom: 8, fontSize: 14 }}>• {tip}</Text>
                ))}
              </View>
            )}
          </View>

          {/* Educational Section */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Carbon Facts 🌍</Text>
            <View style={{ backgroundColor: '#E3F2FD', padding: 15, borderRadius: 10, marginBottom: 10 }}>
              <Text style={{ color: '#1976D2', fontWeight: '600' }}>🚗 Transportation</Text>
              <Text style={{ color: '#666', fontSize: 12 }}>Car: 0.21 kg/km • Bus: 0.08 kg/km • Bike: 0 kg/km</Text>
            </View>
            <View style={{ backgroundColor: '#E8F5E8', padding: 15, borderRadius: 10, marginBottom: 10 }}>
              <Text style={{ color: '#4CAF50', fontWeight: '600' }}>🍽️ Food</Text>
              <Text style={{ color: '#666', fontSize: 12 }}>Beef: 27 kg/kg • Chicken: 6.9 kg/kg • Vegetables: 2 kg/kg</Text>
            </View>
            <View style={{ backgroundColor: '#FFF3E0', padding: 15, borderRadius: 10 }}>
              <Text style={{ color: '#FF9800', fontWeight: '600' }}>⚡ Energy</Text>
              <Text style={{ color: '#666', fontSize: 12 }}>Electricity: 0.5 kg/kWh • Solar: 0.05 kg/kWh</Text>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}