import { Text, TouchableOpacity, View } from 'react-native';
import { Habit } from '../types';

interface HabitTrackerProps {
  habits: Habit[];
  onUpdateHabit: (habitId: string) => void;
}

export function HabitTracker({ habits, onUpdateHabit }: HabitTrackerProps) {
  return (
    <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10, marginBottom: 15 }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15 }}>Daily Habits</Text>
      {habits.map((habit) => (
        <TouchableOpacity
          key={habit.id}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            paddingVertical: 12,
            borderBottomWidth: 1,
            borderBottomColor: '#f0f0f0'
          }}
          onPress={() => !habit.completed && onUpdateHabit(habit.id)}
          disabled={habit.completed}
        >
          <View style={{
            width: 24,
            height: 24,
            borderRadius: 12,
            borderWidth: 2,
            borderColor: habit.completed ? '#4CAF50' : '#ccc',
            backgroundColor: habit.completed ? '#4CAF50' : 'transparent',
            marginRight: 15,
            justifyContent: 'center',
            alignItems: 'center'
          }}>
            {habit.completed && (
              <Text style={{ color: 'white', fontSize: 14, fontWeight: 'bold' }}>✓</Text>
            )}
          </View>
          <Text style={{ 
            flex: 1, 
            color: habit.completed ? '#888' : '#000',
            textDecorationLine: habit.completed ? 'line-through' : 'none'
          }}>
            {habit.name}
          </Text>
          <Text style={{ 
            color: habit.completed ? '#4CAF50' : '#666',
            fontWeight: 'bold'
          }}>
            +{habit.points} pts
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}