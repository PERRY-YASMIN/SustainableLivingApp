import { ScrollView, Text, View } from 'react-native';
import { User } from '../types';

interface ImpactDashboardProps {
  user: User | null;
}

export function ImpactDashboard({ user }: ImpactDashboardProps) {
  const weeklyData = [25, 30, 22, 35, 28, 40, 38]; // Example CO2 savings per day

  const stats = [
    { label: 'Total CO₂ Saved', value: `${user?.carbonSaved || 0} kg`, icon: '🌍' },
    { label: 'Eco Points', value: user?.points || 0, icon: '⭐' },
    { label: 'Badges Earned', value: user?.badges?.length || 0, icon: '🏆' },
    { label: 'Habits Completed', value: '42', icon: '✅' },
  ];

  // Sample badges data in case user has none - fixed the assignment
  const sampleBadges = ['Eco Warrior', 'Plastic Free', 'Energy Saver'];
  const userBadges = user?.badges && user.badges.length > 0 ? user.badges : sampleBadges;

  return (
    <ScrollView style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Your Impact Dashboard</Text>
      
      {/* Stats Grid */}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 20 }}>
        {stats.map((stat, index) => (
          <View
            key={index}
            style={{
              width: '48%',
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 10,
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 2
            }}
          >
            <Text style={{ fontSize: 24, marginBottom: 5 }}>{stat.icon}</Text>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#4CAF50' }}>{stat.value}</Text>
            <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>{stat.label}</Text>
          </View>
        ))}
      </View>

      {/* CO2 Savings Chart */}
      <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10, marginBottom: 15 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 15 }}>Weekly CO₂ Savings (kg)</Text>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120 }}>
          {weeklyData.map((value, index) => (
            <View key={index} style={{ flex: 1, alignItems: 'center' }}>
              <View
                style={{
                  width: 20,
                  height: (value / Math.max(...weeklyData)) * 80,
                  backgroundColor: '#4CAF50',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  marginHorizontal: 2
                }}
              />
              <Text style={{ fontSize: 10, marginTop: 5 }}>{['M', 'T', 'W', 'T', 'F', 'S', 'S'][index]}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Habits Completion */}
      <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10, marginBottom: 15 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 15 }}>Habits Completion Rate</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
          <View style={{ flex: 1, height: 10, backgroundColor: '#f0f0f0', borderRadius: 5 }}>
            <View 
              style={{ 
                width: '75%', 
                height: 10, 
                backgroundColor: '#4CAF50', 
                borderRadius: 5 
              }} 
            />
          </View>
          <Text style={{ marginLeft: 10, fontWeight: 'bold', color: '#4CAF50' }}>75%</Text>
        </View>
        <Text style={{ color: '#666', fontSize: 12 }}>You're doing better than 68% of users!</Text>
      </View>

      {/* Recent Achievements */}
      <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>Recent Achievements</Text>
        {userBadges.slice(0, 3).map((badge, index) => (
          <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
            <Text style={{ fontSize: 20, marginRight: 10 }}>🏆</Text>
            <View>
              <Text style={{ fontWeight: 'bold' }}>{badge}</Text>
              <Text style={{ color: '#666', fontSize: 12 }}>Earned 2 days ago</Text>
            </View>
          </View>
        ))}
        {userBadges.length === 0 && (
          <Text style={{ color: '#666', fontStyle: 'italic' }}>No badges earned yet. Complete challenges to earn badges!</Text>
        )}
      </View>
    </ScrollView>
  );
}