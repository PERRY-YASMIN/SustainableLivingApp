import { Text, TouchableOpacity, View } from 'react-native';
import { Challenge } from '../types';

interface EcoChallengeProps {
  challenge: Challenge;
}

export function EcoChallenge({ challenge }: EcoChallengeProps) {
  return (
    <View style={{ backgroundColor: 'white', padding: 15, borderRadius: 10, marginBottom: 15 }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>Weekly Challenge</Text>
      <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#4CAF50', marginBottom: 5 }}>
        {challenge.name}
      </Text>
      <Text style={{ color: '#666', marginBottom: 10 }}>{challenge.description}</Text>
      
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ color: '#888' }}>{challenge.participants} participants</Text>
        <TouchableOpacity style={{ backgroundColor: '#4CAF50', paddingHorizontal: 20, paddingVertical: 8, borderRadius: 15 }}>
          <Text style={{ color: 'white', fontWeight: 'bold' }}>Join Challenge</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}