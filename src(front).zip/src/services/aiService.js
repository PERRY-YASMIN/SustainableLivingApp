const GEMINI_API_KEY = 'AIzaSyAhAqnxnPTOlfPKY8VJWbZy40wiTu0mILI';

export const generateEcoTip = async (userContext = '') => {
  try {
    console.log('🌱 Generating eco-tip with GEMINI AI...');
    
    const prompt = userContext 
      ? `Give me one practical sustainable living tip for ${userContext}. Make it actionable, specific, and include why it helps the environment.`
      : "Give me one practical sustainable living tip for college students. Make it actionable, specific, and include why it helps the environment.";
    
    const API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ]
      })
    });

    if (response.ok) {
      const data = await response.json();
      console.log('✅ AI Eco-tip generated successfully');
      return data.candidates[0].content.parts[0].text;
    } else {
      console.log('🔄 AI service down, using smart mock');
      throw new Error('Fallback to mock');
    }
    
  } catch (error) {
    console.log('🤖 Using smart eco-tip generator');
    
    // Context-aware mock eco-tips
    const contextTips = {
      student: [
        "📚 Digital Textbook Strategy: Use your university's e-library instead of buying physical books. This saves an average of 3-5 trees per semester and makes your backpack much lighter! Plus, digital books are searchable and accessible anywhere.",
        
        "🚲 Active Campus Commute: Walk or bike to classes within 1 mile. You'll get natural exercise (about 2,000 extra steps daily), reduce carbon emissions, and often arrive faster than dealing with campus parking! Many students report better focus after active commutes.",
        
        "💧 Hydration Station Habit: Always carry a reusable water bottle and refill at campus hydration stations. If you buy just 2 plastic bottles weekly, switching to reusable saves $100+ yearly and prevents 100+ plastic bottles from entering landfills.",
        
        "💡 Study Smart Locations: Use library or common areas with natural light instead of your dorm room during daytime. This reduces individual energy consumption by 40-60% and the change of scenery can boost productivity and creativity."
      ],
      default: [
        "🌱 Start Small, Win Big: Choose ONE sustainable habit to master this month. Consistency with one change creates more impact than sporadically trying many. This month: perfect reusable coffee cup usage. Next month: master meal planning.",
        
        "🛒 The 24-Hour Rule: Before any purchase, wait 24 hours. This simple pause reduces impulse buys by 70% and prevents waste from items you don't truly need or use. Your wallet and the planet will thank you!",
        
        "💚 Eco-Buddy System: Partner with a friend to share sustainability goals. Weekly check-ins increase habit consistency by 300%. Share tips, celebrate wins, and keep each other motivated on your eco-journey.",
        
        "🍽️ Meal Prep Sundays: Cook 2-3 base ingredients in bulk (rice, roasted veggies, beans) and mix creatively throughout the week. Reduces food waste by 40%, saves 5+ cooking hours weekly, and makes healthy eating effortless."
      ]
    };

    const tips = userContext.toLowerCase().includes('student') ? contextTips.student : contextTips.default;
    const randomTip = tips[Math.floor(Math.random() * tips.length)];
    
    await new Promise(resolve => setTimeout(resolve, 1200));
    return randomTip;
  }
};

// Keep the original function for backward compatibility
export const askGemini = generateEcoTip;