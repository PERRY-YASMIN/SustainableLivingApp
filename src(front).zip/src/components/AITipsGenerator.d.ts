declare const AITipsGenerator: () => JSX.Element;
export default AITipsGenerator;