import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Animated, Easing, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { generateEcoTip } from '../services/aiService';

export default function AITipsGenerator() {
  const [aiTip, setAiTip] = useState('');
  const [loading, setLoading] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;
  const tipAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const generateTip = async () => {
    setLoading(true);
    setAiTip('');
    
    // Button press animation
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();

    try {
      const tip = await generateEcoTip("college student");
      setAiTip(tip);
      
      // Animate tip appearance
      Animated.timing(tipAnim, {
        toValue: 1,
        duration: 500,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
    } catch (error) {
      Alert.alert('Tip Generation', 'Unable to generate tip at the moment. Please try again.');
    }
    setLoading(false);
  };

  return (
    <Animated.View 
      style={{ 
        backgroundColor: 'rgba(76, 175, 80, 0.1)',
        padding: 25, 
        borderRadius: 20, 
        margin: 15,
        borderLeftWidth: 6,
        borderLeftColor: '#4CAF50',
        shadowColor: '#4CAF50',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.2,
        shadowRadius: 12,
        elevation: 6,
        opacity: fadeAnim,
        transform: [{ scale: scaleAnim }],
      }}
    >
      <View style={{ alignItems: 'center', marginBottom: 20 }}>
        <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 8, color: '#4CAF50' }}>
          🤖 AI Sustainability Coach
        </Text>
        
        <Text style={{ fontSize: 16, color: '#666', textAlign: 'center', lineHeight: 22 }}>
          Get personalized eco-tips powered by AI to enhance your sustainability journey
        </Text>
      </View>
      
      <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
        <TouchableOpacity 
          style={{ 
            backgroundColor: loading ? '#CCCCCC' : '#4CAF50', 
            padding: 18, 
            borderRadius: 15,
            marginBottom: 15,
            shadowColor: '#4CAF50',
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: loading ? 0 : 0.4,
            shadowRadius: 8,
            elevation: loading ? 0 : 6,
          }}
          onPress={generateTip}
          disabled={loading}
        >
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
            {loading && <ActivityIndicator color="white" style={{ marginRight: 12 }} size="small" />}
            <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', fontSize: 16 }}>
              {loading ? 'Generating Your Eco Tip...' : '🎯 Get Daily Eco Tip'}
            </Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
      
      {aiTip ? (
        <Animated.View 
          style={{ 
            opacity: tipAnim,
            transform: [{
              translateY: tipAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [10, 0],
              }),
            }],
          }}
        >
          <ScrollView style={{ maxHeight: 200 }} showsVerticalScrollIndicator={false}>
            <View style={{ 
              backgroundColor: 'white', 
              padding: 20, 
              borderRadius: 15,
              borderWidth: 1,
              borderColor: '#E8F5E8',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 8,
              elevation: 3,
            }}>
              <View style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12 }}>
                <Text style={{ fontSize: 20, marginRight: 10 }}>💡</Text>
                <Text style={{ fontWeight: 'bold', color: '#4CAF50', fontSize: 16, flex: 1 }}>
                  Today's Personalized Tip
                </Text>
              </View>
              <Text style={{ fontSize: 15, color: '#333', lineHeight: 22, textAlign: 'left' }}>
                {aiTip}
              </Text>
            </View>
          </ScrollView>
        </Animated.View>
      ) : (
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.5)', 
          padding: 20, 
          borderRadius: 15,
          alignItems: 'center',
        }}>
          <Text style={{ fontSize: 48, marginBottom: 10 }}>🌱</Text>
          <Text style={{ color: '#666', fontSize: 14, textAlign: 'center' }}>
            Tap the button above to get your personalized eco tip!
          </Text>
        </View>
      )}
    </Animated.View>
  );
}