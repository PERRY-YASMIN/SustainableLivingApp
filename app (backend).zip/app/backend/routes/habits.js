const express = require('express');
const {
  getHabits,
  completeHabit,
  getUserProgress
} = require('../controllers/habitController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, getHabits);
router.post('/complete/:habitId', protect, completeHabit);
router.get('/progress', protect, getUserProgress);

module.exports = router;