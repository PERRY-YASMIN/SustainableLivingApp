const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
require('dotenv').config();

const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

console.log('Starting EcoCampus Backend...');

// Basic route
app.get('/', (req, res) => {
  res.json({ 
    message: 'EcoCampus API is running!',
    timestamp: new Date().toISOString()
  });
});

// Test route
app.get('/api/test', (req, res) => {
  res.json({ 
    message: 'API is working!',
    timestamp: new Date().toISOString()
  });
});

// Test if we can load auth routes
try {
  console.log('Loading auth routes...');
  app.use('/api/auth', require('./routes/auth'));
  console.log('✅ Auth routes loaded successfully');
} catch (error) {
  console.log('❌ Auth routes failed:', error.message);
}

// Test if we can load habit routes  
try {
  console.log('Loading habit routes...');
  app.use('/api/habits', require('./routes/habits'));
  console.log('✅ Habit routes loaded successfully');
} catch (error) {
  console.log('❌ Habit routes failed:', error.message);
  console.log('Error details:', error);
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log('✅ Server running on port', PORT);
  console.log('📱 API URL: http://localhost:' + PORT);
});