// Simple server test without routes
const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Simple test - server works' });
});

console.log('Testing basic server...');
app.listen(5001, () => {
  console.log('Basic test server running on port 5001');
});