// Updated test for habit system
const testHabits = async () => {
  console.log('Testing Habit System...\n');
  
  try {
    // First login to get token
    console.log('1. Logging in...');
    const loginResponse = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'yasmin@example.com',
        password: 'password123'
      })
    });
    
    if (!loginResponse.ok) {
      const errorData = await loginResponse.json();
      console.log('Login failed:', errorData.message);
      return;
    }
    
    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful');
    
    // Test getting habits
    console.log('\n2. Getting all habits...');
    const habitsResponse = await fetch('http://localhost:5000/api/habits', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });
    
    if (!habitsResponse.ok) {
      const errorData = await habitsResponse.json();
      console.log('❌ Get habits failed:', errorData.message);
      return;
    }
    
    const habits = await habitsResponse.json();
    console.log('✅ Habits received:', habits.length, 'habits');
    
    if (Array.isArray(habits)) {
      habits.forEach(habit => {
        console.log(`   - ${habit.icon || '📝'} ${habit.title} (${habit.points} points)`);
      });
      
      // Test completing the first habit
      if (habits.length > 0) {
        console.log('\n3. Completing first habit...');
        const completeResponse = await fetch(`http://localhost:5000/api/habits/complete/${habits[0].id}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });
        
        const completionResult = await completeResponse.json();
        if (completeResponse.ok) {
          console.log('✅ Habit completed!');
          console.log('   Points earned:', completionResult.pointsEarned);
          console.log('   Carbon saved:', completionResult.carbonSaved);
          console.log('   New total points:', completionResult.newPoints);
        } else {
          console.log('❌ Habit completion failed:', completionResult.message);
        }
      }
    } else {
      console.log('❌ Habits data is not an array:', typeof habits);
    }
    
    console.log('\n🎉 Habit system test completed!');
    
  } catch (error) {
    console.log('❌ Error:', error.message);
  }
};

testHabits();