const memoryStorage = require('../utils/memoryStorage');

// @desc    Get all habits
// @route   GET /api/habits
// @access  Private
const getHabits = async (req, res) => {
  try {
    const habits = await memoryStorage.getHabits();
    res.json(habits);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Complete a habit
// @route   POST /api/habits/complete/:habitId
// @access  Private
const completeHabit = async (req, res) => {
  try {
    const { habitId } = req.params;
    const userId = req.user.id;

    // Get user and habit
    const user = await memoryStorage.getUserById(userId);
    const habits = await memoryStorage.getHabits();
    const habit = habits.find(h => h.id === habitId);

    if (!habit) {
      return res.status(404).json({ message: 'Habit not found' });
    }

    // Check if already completed today
    const today = new Date().toDateString();
    
    // Initialize completedHabits if it doesn't exist
    if (!user.completedHabits) {
      user.completedHabits = {};
    }
    
    const lastCompleted = user.completedHabits[habitId]?.lastCompleted;
    
    if (lastCompleted === today && habit.frequency === 'daily') {
      return res.status(400).json({ message: 'Habit already completed today' });
    }

    // Update user points and carbon saved
    user.points += habit.points;
    user.carbonSaved = (user.carbonSaved || 0) + habit.carbonReduction;

    // Track completed habit
    user.completedHabits[habitId] = {
      lastCompleted: today,
      timesCompleted: (user.completedHabits[habitId]?.timesCompleted || 0) + 1
    };

    // Update streak
    user.streak = (user.streak || 0) + 1;

    // Save user
    await memoryStorage.setUser(user);

    res.json({
      message: 'Habit completed!',
      pointsEarned: habit.points,
      carbonSaved: habit.carbonReduction,
      newPoints: user.points,
      newCarbonSaved: user.carbonSaved,
      streak: user.streak
    });

  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Get user habit progress
// @route   GET /api/habits/progress
// @access  Private
const getUserProgress = async (req, res) => {
  try {
    const user = await memoryStorage.getUserById(req.user.id);
    const habits = await memoryStorage.getHabits();
    
    const progress = habits.map(habit => {
      const completion = user.completedHabits?.[habit.id] || {};
      const isCompletedToday = completion.lastCompleted === new Date().toDateString();
      
      return {
        ...habit,
        completed: isCompletedToday,
        timesCompleted: completion.timesCompleted || 0,
        lastCompleted: completion.lastCompleted
      };
    });

    res.json(progress);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = {
  getHabits,
  completeHabit,
  getUserProgress
};