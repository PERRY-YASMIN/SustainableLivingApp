const memoryStorage = require('../utils/memoryStorage');
const generateToken = require('../utils/generateToken');

// Simple ID generator
const generateId = () => Math.random().toString(36).substr(2, 9);

// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
  try {
    const { name, email, password, campus } = req.body;

    // Check if user exists
    const userExists = await memoryStorage.getUserByEmail(email);
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create user
    const user = {
      id: generateId(),
      name,
      email,
      password, // In real app, hash this!
      campus,
      points: 100,
      carbonSaved: 0,
      badges: ['beginner'],
      completedHabits: [],
      streak: 0,
      lastActive: new Date(),
      createdAt: new Date()
    };

    await memoryStorage.setUser(user);

    res.status(201).json({
      id: user.id,
      name: user.name,
      email: user.email,
      points: user.points,
      carbonSaved: user.carbonSaved,
      badges: user.badges,
      token: generateToken(user.id),
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check for user email
    const user = await memoryStorage.getUserByEmail(email);

    // Simple password check (in real app, use bcrypt)
    if (user && user.password === password) {
      // Update last active
      user.lastActive = new Date();
      await memoryStorage.setUser(user);

      res.json({
        id: user.id,
        name: user.name,
        email: user.email,
        points: user.points,
        carbonSaved: user.carbonSaved,
        badges: user.badges,
        token: generateToken(user.id),
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Get user profile
// @route   GET /api/auth/profile
// @access  Private
const getUserProfile = async (req, res) => {
  try {
    const user = await memoryStorage.getUserById(req.user.id);
    
    if (user) {
      // Don't send password back
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUserProfile
};