// Simple token generation for development
const generateToken = (id) => {
  return id; // Just return the user ID for now
};

module.exports = generateToken;