// Simple in-memory database for development
let users = [];
let habits = [];
let challenges = [];

// Preload some sample habits
const sampleHabits = [
  {
    id: '1',
    title: 'Use Reusable Water Bottle',
    description: 'Avoid single-use plastic bottles',
    category: 'waste',
    points: 10,
    carbonReduction: 0.5,
    difficulty: 'easy',
    frequency: 'daily',
    icon: '💧'
  },
  {
    id: '2', 
    title: 'Walk or Bike to Campus',
    description: 'Avoid driving for short distances',
    category: 'transport',
    points: 15,
    carbonReduction: 1.2,
    difficulty: 'medium',
    frequency: 'daily',
    icon: '🚶'
  },
  {
    id: '3',
    title: 'Turn Off Lights',
    description: 'Switch off lights when leaving room',
    category: 'energy', 
    points: 5,
    carbonReduction: 0.3,
    difficulty: 'easy',
    frequency: 'daily',
    icon: '💡'
  }
];

// Initialize with sample data
habits = [...sampleHabits];

const memoryStorage = {
  // User methods
  async setUser(user) {
    const existingIndex = users.findIndex(u => u.email === user.email);
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    return user;
  },

  async getUserByEmail(email) {
    return users.find(user => user.email === email);
  },

  async getUserById(id) {
    return users.find(user => user.id === id);
  },

  async updateUser(userId, updates) {
    const index = users.findIndex(u => u.id === userId);
    if (index >= 0) {
      users[index] = { ...users[index], ...updates };
      return users[index];
    }
    return null;
  },

  async getAllUsers() {
    return users;
  },

  // Habit methods
  async getHabits() {
    return habits;
  },

  async updateHabit(habitId, updates) {
    const index = habits.findIndex(h => h.id === habitId);
    if (index >= 0) {
      habits[index] = { ...habits[index], ...updates };
      return habits[index];
    }
    return null;
  },

  // Challenge methods
  async getChallenges() {
    return challenges;
  },

  async addChallenge(challenge) {
    challenges.push(challenge);
    return challenge;
  }
};

module.exports = memoryStorage;