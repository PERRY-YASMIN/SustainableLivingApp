// Simple API test script
const testAPI = async () => {
  console.log('🧪 Testing EcoCampus API...\n');
  
  try {
    // Test 1: Basic API connection
    console.log('1. Testing basic API connection...');
    const testResponse = await fetch('http://localhost:5000/api/test');
    const testData = await testResponse.json();
    console.log('✅ Basic API test:', testData.message);
    
    // Test 2: User Registration
    console.log('\n2. Testing user registration...');
    const registerResponse = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: 'Yasmin',
        email: 'yasmin@example.com',
        password: 'password123',
        campus: 'Main Campus'
      })
    });
    
    const userData = await registerResponse.json();
    
    if (registerResponse.ok) {
      console.log('✅ Registration successful!');
      console.log('   User:', userData.name);
      console.log('   Points:', userData.points);
      console.log('   Token received:', userData.token ? 'Yes' : 'No');
    } else {
      console.log('❌ Registration failed:', userData.message);
    }
    
    // Test 3: User Login
    console.log('\n3. Testing user login...');
    const loginResponse = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'yasmin@example.com',
        password: 'password123'
      })
    });
    
    const loginData = await loginResponse.json();
    
    if (loginResponse.ok) {
      console.log('✅ Login successful!');
      console.log('   User:', loginData.name);
      console.log('   Points:', loginData.points);
      
      // Test 4: Get User Profile (with token)
      console.log('\n4. Testing profile access with token...');
      const profileResponse = await fetch('http://localhost:5000/api/auth/profile', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${loginData.token}`,
          'Content-Type': 'application/json',
        },
      });
      
      const profileData = await profileResponse.json();
      
      if (profileResponse.ok) {
        console.log('✅ Profile access successful!');
        console.log('   User data:', {
          name: profileData.name,
          email: profileData.email,
          points: profileData.points,
          carbonSaved: profileData.carbonSaved,
          badges: profileData.badges
        });
      } else {
        console.log('❌ Profile access failed:', profileData.message);
      }
    } else {
      console.log('❌ Login failed:', loginData.message);
    }
    
    console.log('\n🎉 All tests completed!');
    
  } catch (error) {
    console.log('❌ Error running tests:', error.message);
    console.log('💡 Make sure your server is running on http://localhost:5000');
  }
};

// Run the tests
testAPI();