import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { UserDetailsForm } from './components/UserDetailsForm';
import { OnboardingData, User } from './types';
import { Storage, defaultHabits, defaultUser } from './utils/storage';

export default function UserDetailsScreen() {
  const router = useRouter();
  const [existingUser, setExistingUser] = useState<User | null>(null);

  useEffect(() => {
    loadExistingUser();
  }, []);

  const loadExistingUser = async () => {
    const user = await Storage.get('user');
    console.log('Loading existing user:', user);
    if (user) {
      setExistingUser(user);
    }
  };

  const handleComplete = async (data: OnboardingData) => {
    console.log('Completing onboarding with data:', data);
    
    // CRITICAL: Make sure ALL fields are properly set, especially MAJOR
    const updatedUser: User = {
      ...defaultUser,
      ...existingUser, // Preserve existing data
      name: data.name || 'Student',
      campus: data.campus || 'Karunya University',
      major: data.major || 'Computer Science', // THIS MUST BE SET
      year: data.year || '1st Year',
      sustainabilityInterest: data.sustainabilityInterest || 'beginner',
      dailyCommute: data.dailyCommute || 'walking',
      dietaryPreference: data.dietaryPreference || 'vegetarian',
      energyHabits: data.energyHabits || [],
      joinDate: new Date().toISOString(),
      habits: defaultHabits,
    };

    console.log('Saving user with major field:', updatedUser.major);

    // Save to storage
    await Storage.set('user', updatedUser);
    await Storage.set('habits', defaultHabits);
    
    // Verify the save worked
    const savedUser = await Storage.get('user');
    console.log('Verified saved user has major:', savedUser?.major);
    
    // Navigate to home
    console.log('Navigating to home...');
    router.replace('/(tabs)');
  };

  const handleSkip = async () => {
    console.log('User skipped onboarding');
    
    // Create a basic user with MAJOR field to prevent reopening
    const skippedUser: User = {
      ...defaultUser,
      ...existingUser,
      name: existingUser?.name || 'Student',
      campus: 'Karunya University',
      major: 'Undeclared', // CRITICAL: Add major field even when skipping
      joinDate: new Date().toISOString(),
      habits: defaultHabits,
    };

    console.log('Saving skipped user with major:', skippedUser.major);
    await Storage.set('user', skippedUser);
    await Storage.set('habits', defaultHabits);
    
    // Verify
    const savedUser = await Storage.get('user');
    console.log('Verified skipped user has major:', savedUser?.major);
    
    console.log('Navigating to home after skip...');
    router.replace('/(tabs)');
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      <UserDetailsForm onComplete={handleComplete} onSkip={handleSkip} />
    </View>
  );
}