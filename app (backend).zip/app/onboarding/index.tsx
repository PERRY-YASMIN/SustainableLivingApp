import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function OnboardingScreen() {
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    campus: '',
  });

  const handleSubmit = () => {
    // For demo - just redirect to home
    router.replace('/(tabs)');
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}>
        <View style={{ padding: 20 }}>
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 40 }}>
            <View style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: '#4CAF50',
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 20
            }}>
              <Ionicons name="leaf" size={40} color="white" />
            </View>
            <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#4CAF50', textAlign: 'center' }}>
              EcoCampus
            </Text>
            <Text style={{ fontSize: 16, color: '#666', textAlign: 'center', marginTop: 10 }}>
              {isLogin ? 'Welcome Back!' : 'Join EcoCampus'}
            </Text>
          </View>

          {/* Form Container */}
          <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15, elevation: 3 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 30, textAlign: 'center' }}>
              {isLogin ? 'Sign In' : 'Sign Up'}
            </Text>

            {!isLogin && (
              <View style={{ marginBottom: 15 }}>
                <Text style={{ fontWeight: '600', marginBottom: 5, color: '#333' }}>Full Name</Text>
                <TextInput
                  style={{ 
                    borderWidth: 1, 
                    borderColor: '#ccc', 
                    borderRadius: 10, 
                    padding: 15,
                    fontSize: 16,
                  }}
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChangeText={(text) => setFormData({...formData, name: text})}
                />
              </View>
            )}

            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontWeight: '600', marginBottom: 5, color: '#333' }}>Email</Text>
              <TextInput
                style={{ 
                  borderWidth: 1, 
                  borderColor: '#ccc', 
                  borderRadius: 10, 
                  padding: 15,
                  fontSize: 16,
                }}
                placeholder="Enter your email"
                keyboardType="email-address"
                autoCapitalize="none"
                value={formData.email}
                onChangeText={(text) => setFormData({...formData, email: text})}
              />
            </View>

            {!isLogin && (
              <View style={{ marginBottom: 15 }}>
                <Text style={{ fontWeight: '600', marginBottom: 5, color: '#333' }}>Campus</Text>
                <TextInput
                  style={{ 
                    borderWidth: 1, 
                    borderColor: '#ccc', 
                    borderRadius: 10, 
                    padding: 15,
                    fontSize: 16,
                  }}
                  placeholder="Select your campus"
                  value={formData.campus}
                  onChangeText={(text) => setFormData({...formData, campus: text})}
                />
              </View>
            )}

            <View style={{ marginBottom: 25 }}>
              <Text style={{ fontWeight: '600', marginBottom: 5, color: '#333' }}>Password</Text>
              <TextInput
                style={{ 
                  borderWidth: 1, 
                  borderColor: '#ccc', 
                  borderRadius: 10, 
                  padding: 15,
                  fontSize: 16,
                }}
                placeholder="Enter your password"
                secureTextEntry
                value={formData.password}
                onChangeText={(text) => setFormData({...formData, password: text})}
              />
            </View>

            <TouchableOpacity 
              style={{ 
                backgroundColor: '#4CAF50', 
                padding: 15, 
                borderRadius: 10, 
                marginBottom: 10 
              }}
              onPress={handleSubmit}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                {isLogin ? 'Sign In' : 'Sign Up'} (Demo)
              </Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={{ 
                backgroundColor: '#666', 
                padding: 15, 
                borderRadius: 10, 
                marginBottom: 15 
              }}
              onPress={() => router.replace('/(tabs)')}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                Quick Demo (Skip Login)
              </Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => setIsLogin(!isLogin)}
              style={{ padding: 10 }}
            >
              <Text style={{ color: '#4CAF50', textAlign: 'center' }}>
                {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
              </Text>
            </TouchableOpacity>
          </View>

          {/* ADDED AI TEST COMPONENT */}
          
          
        </View>
      </ScrollView>
    </View>
  );
}