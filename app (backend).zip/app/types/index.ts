export interface User {
  id: string;
  name: string;
  email: string;
  points: number;
  carbonSaved: number;
  habits: Habit[];
  badges: string[];
  campus?: string;
  completedHabits: string[];
  // NEW FIELDS
  major?: string;
  year?: string;
  sustainabilityInterest?: string;
  dailyCommute?: string;
  dietaryPreference?: string;
  energyHabits?: string[];
  joinDate?: string;
}

export interface OnboardingData {
  name: string;
  campus: string;
  major: string;
  year: string;
  sustainabilityInterest: string;
  dailyCommute: string;
  dietaryPreference: string;
  energyHabits: string[];
}

export interface Habit {
  id: string;
  name: string;
  completed: boolean;
  points: number;
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  duration: number;
  participants: number;
  completed?: boolean;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export type FoodItem = {
  id: string;
  name: string;
  category: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber: number;
  vitamins: string[];
};

export type Meal = {
  id: string;
  type: MealType;
  foods: FoodItem[];
  timestamp: Date;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  isHealthy: boolean;
};