import AsyncStorage from '@react-native-async-storage/async-storage';
import { Habit, User } from '../types';

export const Storage = {
  set: async (key: string, value: any) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.log('Storage set error:', error);
    }
  },

  get: async (key: string) => {
    try {
      const value = await AsyncStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      console.log('Storage get error:', error);
      return null;
    }
  },

  remove: async (key: string) => {
    try {
      await AsyncStorage.removeItem(key);
    } catch (error) {
      console.log('Storage remove error:', error);
    }
  }
};

export const defaultUser: User = {
  id: '1',
  name: 'YASMIN', // CHANGED TO YASMIN
  email: 'yasmin@karunya.edu.in', // ADDED EMAIL
  campus: 'Karunya University',
  points: 325,
  badges: ['eco-warrior', 'water-saver', 'green-commuter'],
  carbonSaved: 42.7,
  completedHabits: ['1', '3', '4'],
  habits: [] // ADDED HABITS ARRAY
};

export const defaultHabits: Habit[] = [
  { id: '1', name: 'Used reusable bottle', completed: false, points: 10 },
  { id: '2', name: 'Walked instead of driving', completed: false, points: 15 },
  { id: '3', name: 'Reduced electricity use', completed: false, points: 10 },
  { id: '4', name: 'Recycled properly', completed: false, points: 8 },
  { id: '5', name: 'Meat-free meal', completed: false, points: 12 },
  { id: '6', name: '30 mins exercise', completed: false, points: 20 }, // New exercise habit
  { id: '7', name: 'Plant-based meal', completed: false, points: 15 }, // Additional healthy habit
];

// Leaderboard data
export const leaderboardData = [
  { id: '1', name: 'YASMIN', points: 325, carbonSaved: 42.7, rank: 1, avatar: '👑' },
  { id: '2', name: 'AMY', points: 298, carbonSaved: 38.2, rank: 2, avatar: '🌟' },
  { id: '3', name: 'SAM', points: 275, carbonSaved: 35.1, rank: 3, avatar: '⭐' },
  { id: '4', name: 'PRIYA', points: 240, carbonSaved: 30.8, rank: 4, avatar: '💚' },
  { id: '5', name: 'JORDAN', points: 215, carbonSaved: 27.9, rank: 5, avatar: '🌱' },
];

// Nutrition Types
export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export type FoodItem = {
  id: string;
  name: string;
  category: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber: number;
  vitamins: string[];
};

export type Meal = {
  id: string;
  type: MealType;
  foods: FoodItem[];
  timestamp: Date;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  isHealthy: boolean;
};

// Food Database for Nutrition Tracker
export const foodDatabase: FoodItem[] = [
  // Fruits
  { id: '1', name: 'Apple', category: 'fruit', calories: 52, protein: 0.3, carbs: 14, fats: 0.2, fiber: 2.4, vitamins: ['C'] },
  { id: '2', name: 'Banana', category: 'fruit', calories: 89, protein: 1.1, carbs: 23, fats: 0.3, fiber: 2.6, vitamins: ['B6', 'C'] },
  { id: '3', name: 'Orange', category: 'fruit', calories: 47, protein: 0.9, carbs: 12, fats: 0.1, fiber: 2.4, vitamins: ['C'] },
  { id: '4', name: 'Strawberries', category: 'fruit', calories: 32, protein: 0.7, carbs: 7.7, fats: 0.3, fiber: 2, vitamins: ['C'] },
  { id: '5', name: 'Grapes', category: 'fruit', calories: 62, protein: 0.6, carbs: 16, fats: 0.3, fiber: 0.9, vitamins: ['C', 'K'] },
  
  // Vegetables
  { id: '6', name: 'Broccoli', category: 'vegetable', calories: 34, protein: 2.8, carbs: 7, fats: 0.4, fiber: 2.6, vitamins: ['C', 'K'] },
  { id: '7', name: 'Carrot', category: 'vegetable', calories: 41, protein: 0.9, carbs: 10, fats: 0.2, fiber: 2.8, vitamins: ['A'] },
  { id: '8', name: 'Spinach', category: 'vegetable', calories: 23, protein: 2.9, carbs: 3.6, fats: 0.4, fiber: 2.2, vitamins: ['A', 'C', 'K'] },
  { id: '9', name: 'Tomato', category: 'vegetable', calories: 18, protein: 0.9, carbs: 3.9, fats: 0.2, fiber: 1.2, vitamins: ['C', 'K'] },
  { id: '10', name: 'Cucumber', category: 'vegetable', calories: 15, protein: 0.7, carbs: 3.6, fats: 0.1, fiber: 0.5, vitamins: ['K'] },
  
  // Proteins
  { id: '11', name: 'Chicken Breast', category: 'protein', calories: 165, protein: 31, carbs: 0, fats: 3.6, fiber: 0, vitamins: ['B6', 'B12'] },
  { id: '12', name: 'Eggs', category: 'protein', calories: 155, protein: 13, carbs: 1.1, fats: 11, fiber: 0, vitamins: ['B12', 'D'] },
  { id: '13', name: 'Lentils', category: 'protein', calories: 116, protein: 9, carbs: 20, fats: 0.4, fiber: 8, vitamins: ['B'] },
  { id: '14', name: 'Tofu', category: 'protein', calories: 76, protein: 8, carbs: 1.9, fats: 4.8, fiber: 0.3, vitamins: ['B1'] },
  { id: '15', name: 'Salmon', category: 'protein', calories: 206, protein: 22, carbs: 0, fats: 13, fiber: 0, vitamins: ['B12', 'D'] },
  
  // Grains
  { id: '16', name: 'Brown Rice', category: 'grain', calories: 112, protein: 2.6, carbs: 23, fats: 0.8, fiber: 1.8, vitamins: ['B'] },
  { id: '17', name: 'Oats', category: 'grain', calories: 66, protein: 2.4, carbs: 12, fats: 1.4, fiber: 1.7, vitamins: ['B'] },
  { id: '18', name: 'Whole Wheat Bread', category: 'grain', calories: 79, protein: 3.1, carbs: 13, fats: 1, fiber: 1.9, vitamins: ['B'] },
  { id: '19', name: 'Quinoa', category: 'grain', calories: 120, protein: 4.4, carbs: 21, fats: 1.9, fiber: 2.8, vitamins: ['B'] },
  
  // Dairy
  { id: '20', name: 'Milk', category: 'dairy', calories: 42, protein: 3.4, carbs: 5, fats: 1, fiber: 0, vitamins: ['D', 'B12'] },
  { id: '21', name: 'Yogurt', category: 'dairy', calories: 59, protein: 3.5, carbs: 4.7, fats: 1.5, fiber: 0, vitamins: ['B12'] },
  { id: '22', name: 'Cheese', category: 'dairy', calories: 113, protein: 7, carbs: 0.9, fats: 9, fiber: 0, vitamins: ['B12'] },
  
  // Snacks & Others
  { id: '23', name: 'Almonds', category: 'snack', calories: 164, protein: 6, carbs: 6, fats: 14, fiber: 3.5, vitamins: ['E'] },
  { id: '24', name: 'Walnuts', category: 'snack', calories: 185, protein: 4.3, carbs: 3.9, fats: 18, fiber: 1.9, vitamins: ['E'] },
  { id: '25', name: 'Chips', category: 'snack', calories: 152, protein: 2, carbs: 15, fats: 10, fiber: 1, vitamins: [] },
  { id: '26', name: 'Chocolate', category: 'snack', calories: 546, protein: 4.9, carbs: 61, fats: 31, fiber: 3.4, vitamins: [] },
  { id: '27', name: 'Green Tea', category: 'beverage', calories: 1, protein: 0.2, carbs: 0.3, fats: 0, fiber: 0, vitamins: ['C'] },
  { id: '28', name: 'Coffee', category: 'beverage', calories: 1, protein: 0.3, carbs: 0, fats: 0, fiber: 0, vitamins: ['B2', 'B3'] },
];

// Default empty meals array
export const defaultMeals: Meal[] = [];

export default { 
  Storage, 
  defaultUser, 
  defaultHabits, 
  leaderboardData,
  foodDatabase,
  defaultMeals 
};

// Add this to your existing storage.ts file
export const AuthStorage = {
  // Check if user is authenticated and has completed onboarding
  async checkAuthStatus() {
    const user = await Storage.get('user');
    if (!user) return 'not_signed_in';
    if (!user.major) return 'signed_in_no_onboarding';
    return 'signed_in_with_onboarding';
  },

  // Clear all user data (for logout)
  async clearUserData() {
    await Storage.remove('user');
    await Storage.remove('habits');
  }
};