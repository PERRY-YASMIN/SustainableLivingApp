const API_BASE_URL = 'http://localhost:5000/api';

// Helper function for API calls
const apiCall = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'API request failed');
    }
    
    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// Auth API
export const authAPI = {
  async register(userData) {
    return await apiCall('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },

  async login(credentials) {
    return await apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  },

  async getProfile(token) {
    return await apiCall('/auth/profile', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
  },
};

// Habits API
export const habitsAPI = {
  async getHabits(token) {
    return await apiCall('/habits', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
  },

  async completeHabit(habitId, token) {
    return await apiCall(`/habits/complete/${habitId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
  },

  async getProgress(token) {
    return await apiCall('/habits/progress', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
  },
};

// Storage utility that uses the real API
export const Storage = {
  async set(key, value) {
    // For now, we'll use AsyncStorage for local caching
    // In a real app, you might want to cache API responses
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, JSON.stringify(value));
    }
    return value;
  },

  async get(key) {
    if (typeof localStorage !== 'undefined') {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    }
    return null;
  },

  async remove(key) {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(key);
    }
  },
};