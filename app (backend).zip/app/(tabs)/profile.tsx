import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { User } from './../types';
import { Storage, defaultUser } from './../utils/storage';

export default function ProfileScreen() {
  const router = useRouter();
  const [user, setUser] = useState<User>(defaultUser);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const savedUser = await Storage.get('user');
    if (savedUser) setUser(savedUser);
  };

  const handleEditProfile = () => {
    router.push('/user-details');
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      <ScrollView style={{ flex: 1, padding: 20 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Profile 👤</Text>
          <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
            <Text style={styles.editButtonText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>

        {/* Basic Info Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Basic Information</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name:</Text>
            <Text style={styles.infoValue}>{user.name}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Email:</Text>
            <Text style={styles.infoValue}>{user.email}</Text>
          </View>
          {user.campus && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Campus:</Text>
              <Text style={styles.infoValue}>{user.campus}</Text>
            </View>
          )}
          {user.major && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Major:</Text>
              <Text style={styles.infoValue}>{user.major}</Text>
            </View>
          )}
          {user.year && (
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Year:</Text>
              <Text style={styles.infoValue}>{user.year}</Text>
            </View>
          )}
        </View>

        {/* Sustainability Profile Card */}
        {user.sustainabilityInterest && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Sustainability Profile</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Interest Level:</Text>
              <View style={[
                styles.levelBadge,
                { backgroundColor: getInterestLevelColor(user.sustainabilityInterest) }
              ]}>
                <Text style={styles.levelBadgeText}>
                  {getInterestLevelLabel(user.sustainabilityInterest)}
                </Text>
              </View>
            </View>
            {user.dailyCommute && (
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Daily Commute:</Text>
                <Text style={styles.infoValue}>{getCommuteLabel(user.dailyCommute)}</Text>
              </View>
            )}
            {user.dietaryPreference && (
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Dietary Preference:</Text>
                <Text style={styles.infoValue}>{getDietaryLabel(user.dietaryPreference)}</Text>
              </View>
            )}
          </View>
        )}

        {/* Energy Habits Card */}
        {user.energyHabits && user.energyHabits.length > 0 && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Energy Saving Habits</Text>
            {user.energyHabits.map((habit, index) => (
              <View key={index} style={styles.habitItem}>
                <Text style={styles.habitIcon}>✅</Text>
                <Text style={styles.habitText}>{getEnergyHabitLabel(habit)}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Stats Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Your Impact</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{user.points}</Text>
              <Text style={styles.statLabel}>Points</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{user.carbonSaved} kg</Text>
              <Text style={styles.statLabel}>CO₂ Saved</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{user.badges.length}</Text>
              <Text style={styles.statLabel}>Badges</Text>
            </View>
          </View>
        </View>

        {/* Settings Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Settings</Text>
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Notifications</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Privacy</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Help & Support</Text>
          </TouchableOpacity>
        </View>

        {/* Member Since */}
        {user.joinDate && (
          <View style={styles.footer}>
            <Text style={styles.footerText}>
              EcoCampus member since {new Date(user.joinDate).toLocaleDateString()}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

// Helper functions
const getInterestLevelLabel = (level: string) => {
  const labels: { [key: string]: string } = {
    beginner: '🌱 Beginner',
    intermediate: '🌿 Intermediate',
    advanced: '🌳 Advanced',
    expert: '💚 Eco-Expert'
  };
  return labels[level] || level;
};

const getInterestLevelColor = (level: string) => {
  const colors: { [key: string]: string } = {
    beginner: '#4CAF50',
    intermediate: '#2196F3',
    advanced: '#FF9800',
    expert: '#9C27B0'
  };
  return colors[level] || '#4CAF50';
};

const getCommuteLabel = (commute: string) => {
  const labels: { [key: string]: string } = {
    walking: '🚶 Walking',
    bicycle: '🚲 Bicycle',
    public: '🚌 Public Transport',
    car: '🚗 Car',
    carpool: '🚗 Carpool'
  };
  return labels[commute] || commute;
};

const getDietaryLabel = (diet: string) => {
  const labels: { [key: string]: string } = {
    omnivore: '🍖 Omnivore',
    vegetarian: '🥦 Vegetarian',
    vegan: '🌱 Vegan',
    pescatarian: '🐟 Pescatarian'
  };
  return labels[diet] || diet;
};

const getEnergyHabitLabel = (habit: string) => {
  const labels: { [key: string]: string } = {
    lights_off: 'Turn off lights when not in room',
    unplug_electronics: 'Unplug electronics when not in use',
    shorter_showers: 'Take shorter showers',
    efficient_heating: 'Use AC/Heating efficiently',
    natural_light: 'Use natural light when possible'
  };
  return labels[habit] || habit;
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  editButton: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#4CAF50',
  },
  editButtonText: {
    color: '#4CAF50',
    fontWeight: '600',
    fontSize: 14,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  infoLabel: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 16,
    color: '#2c3e50',
    fontWeight: '600',
  },
  levelBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  levelBadgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  habitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  habitIcon: {
    marginRight: 12,
  },
  habitText: {
    fontSize: 14,
    color: '#2c3e50',
    flex: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
  },
  settingItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  settingText: {
    fontSize: 16,
    color: '#2c3e50',
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 40,
  },
  footerText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
});