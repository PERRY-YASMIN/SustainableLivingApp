import { useEffect, useRef } from 'react';
import { Animated, Easing, Text, TouchableOpacity, View } from 'react-native';
import { Challenge } from '../types';

interface EcoChallengeProps {
  challenge: Challenge;
}

export function EcoChallenge({ challenge }: EcoChallengeProps) {
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View 
      style={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        padding: 20, 
        borderRadius: 20, 
        marginBottom: 20,
        shadowColor: '#4CAF50',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 15,
        elevation: 10,
        borderLeftWidth: 6,
        borderLeftColor: '#4CAF50',
        opacity: fadeAnim,
        transform: [{ scale: scaleAnim }],
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <Text style={{ fontSize: 22, fontWeight: 'bold', color: '#2c3e50', flex: 1 }}>
          🌟 Weekly Challenge
        </Text>
        <View style={{ 
          backgroundColor: 'rgba(76, 175, 80, 0.1)', 
          paddingHorizontal: 12, 
          paddingVertical: 6, 
          borderRadius: 12 
        }}>
          <Text style={{ color: '#4CAF50', fontWeight: 'bold', fontSize: 12 }}>
            {challenge.participants} joined
          </Text>
        </View>
      </View>
      
      <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50', marginBottom: 8 }}>
        {challenge.name}
      </Text>
      <Text style={{ color: '#666', marginBottom: 15, fontSize: 14, lineHeight: 20 }}>
        {challenge.description}
      </Text>
      
      <View style={{ 
        flexDirection: 'row', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        backgroundColor: 'rgba(76, 175, 80, 0.05)',
        padding: 12,
        borderRadius: 12,
      }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: 16, marginRight: 8 }}>⏱️</Text>
          <Text style={{ color: '#666', fontSize: 12 }}>{challenge.duration} days remaining</Text>
        </View>
        <TouchableOpacity 
          style={{ 
            backgroundColor: '#4CAF50', 
            paddingHorizontal: 24, 
            paddingVertical: 10, 
            borderRadius: 20,
            shadowColor: '#4CAF50',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.4,
            shadowRadius: 8,
            elevation: 6,
          }}
        >
          <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 14 }}>Join Challenge</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}