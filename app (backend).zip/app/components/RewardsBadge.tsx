import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { User } from '../types';
import { getBadgeProgress } from '../utils/gamification';

interface RewardsBadgeProps {
  user: User | null;
}

export function RewardsBadge({ user }: RewardsBadgeProps) {
  const availableBadges = [
    { 
      id: 'beginner', 
      name: 'Eco Beginner', 
      description: 'Earn 100 points', 
      icon: '🌱', 
      earned: user && user.points >= 100,
      points: 100
    },
    { 
      id: 'saver', 
      name: 'Carbon Saver', 
      description: 'Save 50kg CO₂', 
      icon: '💨', 
      earned: user && user.points >= 500,
      points: 500
    },
    { 
      id: 'habit_hero', 
      name: 'Habit Hero', 
      description: 'Complete 50 habits', 
      icon: '🦸', 
      earned: user && user.points >= 300,
      points: 300
    },
    { 
      id: 'champion', 
      name: 'Eco Champion', 
      description: 'Earn 1000 points', 
      icon: '🏆', 
      earned: user && user.points >= 1000,
      points: 1000
    },
    { 
      id: 'zero_waste', 
      name: 'Zero Waste', 
      description: '7 days no plastic', 
      icon: '🚯', 
      earned: user && user.badges?.includes('zero_waste'),
      points: 750
    },
    { 
      id: 'green_commuter', 
      name: 'Green Commuter', 
      description: '30 bike trips', 
      icon: '🚲', 
      earned: user && user.badges?.includes('green_commuter'),
      points: 600
    },
  ];

  const progress = getBadgeProgress(user?.points || 0);
  const nextPointsNeeded = progress.nextBadge ? progress.nextBadge.points - (user?.points || 0) : 0;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#f5f5f5' }} showsVerticalScrollIndicator={false}>
      {/* Points Summary */}
      <View style={{ backgroundColor: 'white', padding: 20, margin: 15, borderRadius: 15, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }}>
        <Text style={{ fontSize: 16, color: '#666', marginBottom: 5 }}>Your Eco Points</Text>
        <Text style={{ fontSize: 42, fontWeight: 'bold', color: '#FF9800', marginBottom: 10 }}>
          {user?.points || 0}
        </Text>
        
        {progress.nextBadge && (
          <View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 }}>
              <Text style={{ fontSize: 14, color: '#666' }}>Next: {progress.nextBadge.name}</Text>
              <Text style={{ fontSize: 14, color: '#666' }}>{user?.points || 0}/{progress.nextBadge.points}</Text>
            </View>
            <View style={{ height: 8, backgroundColor: '#f0f0f0', borderRadius: 4, overflow: 'hidden' }}>
              <View 
                style={{ 
                  height: '100%', 
                  backgroundColor: '#4CAF50', 
                  width: `${progress.progress}%`,
                  borderRadius: 4
                }} 
              />
            </View>
            <Text style={{ fontSize: 12, color: '#666', marginTop: 5, textAlign: 'center' }}>
              {nextPointsNeeded} points to go!
            </Text>
          </View>
        )}
      </View>

      {/* Badges Section */}
      <View style={{ paddingHorizontal: 15 }}>
        <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#333' }}>Your Badges</Text>
        
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          {availableBadges.map((badge) => (
            <View
              key={badge.id}
              style={{
                width: '48%',
                alignItems: 'center',
                padding: 15,
                marginBottom: 15,
                backgroundColor: badge.earned ? '#E8F5E8' : '#f8f8f8',
                borderRadius: 12,
                borderWidth: 2,
                borderColor: badge.earned ? '#4CAF50' : '#e0e0e0',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 3,
                elevation: 2
              }}
            >
              <Text style={{ fontSize: 36, marginBottom: 8 }}>{badge.icon}</Text>
              <Text style={{ fontWeight: 'bold', textAlign: 'center', marginBottom: 5, color: badge.earned ? '#2E7D32' : '#666' }}>
                {badge.name}
              </Text>
              <Text style={{ fontSize: 12, color: badge.earned ? '#4CAF50' : '#999', textAlign: 'center', marginBottom: 8 }}>
                {badge.description}
              </Text>
              <View style={{
                backgroundColor: badge.earned ? '#4CAF50' : '#ccc',
                paddingHorizontal: 12,
                paddingVertical: 4,
                borderRadius: 12
              }}>
                <Text style={{ 
                  fontSize: 10, 
                  color: 'white', 
                  fontWeight: 'bold',
                  textAlign: 'center'
                }}>
                  {badge.earned ? '✓ EARNED' : `${badge.points} PTS`}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Leaderboard Preview */}
      <View style={{ backgroundColor: 'white', padding: 20, margin: 15, borderRadius: 15, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: '#333' }}>Campus Leaderboard</Text>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, paddingVertical: 8 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#FFD700', marginRight: 8 }}>🥇</Text>
            <View>
              <Text style={{ fontWeight: 'bold' }}>Sarah Chen</Text>
              <Text style={{ fontSize: 12, color: '#666' }}>Environmental Science</Text>
            </View>
          </View>
          <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>1,240 pts</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, paddingVertical: 8 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#C0C0C0', marginRight: 8 }}>🥈</Text>
            <View>
              <Text style={{ fontWeight: 'bold' }}>Marcus Johnson</Text>
              <Text style={{ fontSize: 12, color: '#666' }}>Engineering</Text>
            </View>
          </View>
          <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>980 pts</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15, paddingVertical: 8, backgroundColor: '#F5F5F5', padding: 12, borderRadius: 8 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#CD7F32', marginRight: 8 }}>🥉</Text>
            <View>
              <Text style={{ fontWeight: 'bold' }}>Your Rank</Text>
              <Text style={{ fontSize: 12, color: '#666' }}>Keep going!</Text>
            </View>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>{user?.points || 0} pts</Text>
            <Text style={{ fontSize: 12, color: '#666' }}>#42</Text>
          </View>
        </View>

        <TouchableOpacity style={{ 
          backgroundColor: '#4CAF50', 
          padding: 12, 
          borderRadius: 8, 
          alignItems: 'center',
          marginTop: 10
        }}>
          <Text style={{ color: 'white', fontWeight: 'bold' }}>View Full Leaderboard</Text>
        </TouchableOpacity>
      </View>

      {/* Recent Activity */}
      <View style={{ backgroundColor: 'white', padding: 20, margin: 15, borderRadius: 15, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: '#333' }}>Recent Activity</Text>
        
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12, paddingVertical: 8 }}>
          <Text style={{ fontSize: 20, marginRight: 12 }}>🌱</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '600' }}>Eco Beginner Badge Earned!</Text>
            <Text style={{ fontSize: 12, color: '#666' }}>2 days ago • +100 points</Text>
          </View>
          <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>+100</Text>
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12, paddingVertical: 8 }}>
          <Text style={{ fontSize: 20, marginRight: 12 }}>🚶</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '600' }}>Walked instead of driving</Text>
            <Text style={{ fontSize: 12, color: '#666' }}>Yesterday • 2.5 km</Text>
          </View>
          <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>+15</Text>
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }}>
          <Text style={{ fontSize: 20, marginRight: 12 }}>💧</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '600' }}>Used reusable bottle</Text>
            <Text style={{ fontSize: 12, color: '#666' }}>Today • 3 times</Text>
          </View>
          <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>+10</Text>
        </View>
      </View>
    </ScrollView>
  );
}