import { useEffect, useRef } from 'react';
import { Animated, Easing, Text, TouchableOpacity, View } from 'react-native';
import { Habit } from '../types';

interface HabitTrackerProps {
  habits: Habit[];
  onUpdateHabit: (habitId: string) => void;
}

export function HabitTracker({ habits, onUpdateHabit }: HabitTrackerProps) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View 
      style={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        padding: 20, 
        borderRadius: 20, 
        marginBottom: 20,
        shadowColor: '#2196F3',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.2,
        shadowRadius: 15,
        elevation: 8,
        opacity: fadeAnim,
        transform: [{ translateY: slideAnim }],
      }}
    >
      <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: '#2c3e50' }}>
        📋 Daily Habits
      </Text>
      {habits.map((habit, index) => (
        <TouchableOpacity
          key={habit.id}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            paddingVertical: 14,
            borderBottomWidth: index === habits.length - 1 ? 0 : 1,
            borderBottomColor: 'rgba(0,0,0,0.05)',
          }}
          onPress={() => !habit.completed && onUpdateHabit(habit.id)}
          disabled={habit.completed}
        >
          <View style={{
            width: 28,
            height: 28,
            borderRadius: 14,
            borderWidth: 2,
            borderColor: habit.completed ? '#4CAF50' : '#ddd',
            backgroundColor: habit.completed ? '#4CAF50' : 'transparent',
            marginRight: 16,
            justifyContent: 'center',
            alignItems: 'center',
            shadowColor: habit.completed ? '#4CAF50' : '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: habit.completed ? 0.4 : 0.1,
            shadowRadius: habit.completed ? 4 : 2,
            elevation: habit.completed ? 4 : 1,
          }}>
            {habit.completed && (
              <Text style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>✓</Text>
            )}
          </View>
          <Text style={{ 
            flex: 1, 
            fontSize: 16,
            color: habit.completed ? '#888' : '#2c3e50',
            textDecorationLine: habit.completed ? 'line-through' : 'none',
            fontWeight: habit.completed ? '400' : '500',
          }}>
            {habit.name}
          </Text>
          <View style={{ 
            backgroundColor: habit.completed ? 'rgba(76, 175, 80, 0.1)' : 'rgba(33, 150, 243, 0.1)',
            paddingHorizontal: 12,
            paddingVertical: 6,
            borderRadius: 12,
          }}>
            <Text style={{ 
              color: habit.completed ? '#4CAF50' : '#2196F3',
              fontWeight: 'bold',
              fontSize: 14,
            }}>
              +{habit.points} pts
            </Text>
          </View>
        </TouchableOpacity>
      ))}
      
      {/* Progress Summary */}
      <View style={{ 
        flexDirection: 'row', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginTop: 20,
        paddingTop: 15,
        borderTopWidth: 1,
        borderTopColor: 'rgba(0,0,0,0.05)',
      }}>
        <Text style={{ color: '#666', fontSize: 14 }}>
          {habits.filter(h => h.completed).length} of {habits.length} completed
        </Text>
        <Text style={{ color: '#4CAF50', fontWeight: 'bold', fontSize: 16 }}>
          {Math.round((habits.filter(h => h.completed).length / habits.length) * 100)}%
        </Text>
      </View>
    </Animated.View>
  );
}