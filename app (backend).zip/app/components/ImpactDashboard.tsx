import { useEffect, useRef } from 'react';
import { Animated, Easing, ScrollView, Text, View } from 'react-native';
import { User } from '../types';

interface ImpactDashboardProps {
  user: User | null;
}

export function ImpactDashboard({ user }: ImpactDashboardProps) {
  const weeklyData = [25, 30, 22, 35, 28, 40, 38];
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const stats = [
    { label: 'Total CO₂ Saved', value: `${user?.carbonSaved || 0} kg`, icon: '🌍', color: '#4CAF50' },
    { label: 'Eco Points', value: user?.points || 0, icon: '⭐', color: '#FFC107' },
    { label: 'Badges Earned', value: user?.badges?.length || 0, icon: '🏆', color: '#9C27B0' },
    { label: 'Habits Completed', value: user?.completedHabits?.length || 0, icon: '✅', color: '#2196F3' },
  ];

  const userBadges = user?.badges && user.badges.length > 0 ? user.badges : ['Eco Warrior', 'Plastic Free', 'Energy Saver'];

  return (
    <ScrollView style={{ padding: 20, backgroundColor: '#0a0f2d' }} showsVerticalScrollIndicator={false}>
      <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
        <Text style={{ fontSize: 28, fontWeight: 'bold', marginBottom: 25, color: 'white', textAlign: 'center' }}>
          Your Impact Dashboard 🌟
        </Text>
        
        {/* Stats Grid */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 25 }}>
          {stats.map((stat, index) => (
            <Animated.View
              key={index}
              style={{
                width: '48%',
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                padding: 20,
                borderRadius: 16,
                marginBottom: 15,
                alignItems: 'center',
                shadowColor: stat.color,
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.3,
                shadowRadius: 12,
                elevation: 8,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <Text style={{ fontSize: 32, marginBottom: 8 }}>{stat.icon}</Text>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: stat.color, marginBottom: 4 }}>
                {stat.value}
              </Text>
              <Text style={{ fontSize: 12, color: '#666', textAlign: 'center', fontWeight: '500' }}>
                {stat.label}
              </Text>
            </Animated.View>
          ))}
        </View>

        {/* CO2 Savings Chart */}
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)', 
          padding: 20, 
          borderRadius: 16, 
          marginBottom: 20,
          shadowColor: '#4CAF50',
          shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.2,
          shadowRadius: 12,
          elevation: 6,
        }}>
          <Text style={{ fontWeight: 'bold', marginBottom: 20, fontSize: 18, color: '#2c3e50' }}>
            📊 Weekly CO₂ Savings
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, marginBottom: 15 }}>
            {weeklyData.map((value, index) => (
              <View key={index} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end' }}>
                <View
                  style={{
                    width: 16,
                    height: (value / Math.max(...weeklyData)) * 80,
                    backgroundColor: `rgba(76, 175, 80, ${0.6 + (index * 0.05)})`,
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8,
                    marginHorizontal: 2,
                  }}
                />
                <Text style={{ fontSize: 10, marginTop: 8, fontWeight: '600', color: '#666' }}>
                  {['M', 'T', 'W', 'T', 'F', 'S', 'S'][index]}
                </Text>
                <Text style={{ fontSize: 9, color: '#4CAF50', fontWeight: 'bold', marginTop: 4 }}>
                  {value}kg
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Habits Completion */}
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)', 
          padding: 20, 
          borderRadius: 16, 
          marginBottom: 20,
          shadowColor: '#2196F3',
          shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.2,
          shadowRadius: 12,
          elevation: 6,
        }}>
          <Text style={{ fontWeight: 'bold', marginBottom: 15, fontSize: 18, color: '#2c3e50' }}>
            📈 Habits Completion Rate
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
            <View style={{ flex: 1, height: 12, backgroundColor: '#f0f0f0', borderRadius: 6 }}>
              <View 
                style={{ 
                  width: '75%', 
                  height: 12, 
                  backgroundColor: '#4CAF50', 
                  borderRadius: 6,
                  shadowColor: '#4CAF50',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.4,
                  shadowRadius: 4,
                }} 
              />
            </View>
            <Text style={{ marginLeft: 15, fontWeight: 'bold', color: '#4CAF50', fontSize: 16 }}>75%</Text>
          </View>
          <Text style={{ color: '#666', fontSize: 14, textAlign: 'center' }}>
            🎉 You're doing better than 68% of users!
          </Text>
        </View>

        {/* Recent Achievements */}
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)', 
          padding: 20, 
          borderRadius: 16,
          shadowColor: '#FFC107',
          shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.2,
          shadowRadius: 12,
          elevation: 6,
        }}>
          <Text style={{ fontWeight: 'bold', marginBottom: 15, fontSize: 18, color: '#2c3e50' }}>
            🏆 Recent Achievements
          </Text>
          {userBadges.slice(0, 3).map((badge, index) => (
            <View key={index} style={{ 
              flexDirection: 'row', 
              alignItems: 'center', 
              marginBottom: 15,
              padding: 12,
              backgroundColor: 'rgba(255, 193, 7, 0.1)',
              borderRadius: 12,
              borderLeftWidth: 4,
              borderLeftColor: '#FFC107',
            }}>
              <Text style={{ fontSize: 24, marginRight: 15 }}>🏆</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: 'bold', fontSize: 16, color: '#2c3e50' }}>{badge}</Text>
                <Text style={{ color: '#666', fontSize: 12 }}>Earned 2 days ago</Text>
              </View>
              <View style={{ 
                backgroundColor: '#FFC107', 
                paddingHorizontal: 8, 
                paddingVertical: 4, 
                borderRadius: 12 
              }}>
                <Text style={{ color: 'white', fontSize: 10, fontWeight: 'bold' }}>NEW</Text>
              </View>
            </View>
          ))}
          {userBadges.length === 0 && (
            <Text style={{ color: '#666', fontStyle: 'italic', textAlign: 'center', padding: 20 }}>
              No badges earned yet. Complete challenges to earn badges! 🌱
            </Text>
          )}
        </View>
      </Animated.View>
    </ScrollView>
  );
}