import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { Storage, defaultUser } from './utils/storage';

export default function DashboardScreen() {
  const router = useRouter();
  const [user, setUser] = useState(defaultUser);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const savedUser = await Storage.get('user');
    if (savedUser) setUser(savedUser);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'white',
        paddingTop: 60,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>Detailed Dashboard</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 20 }}>
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15 }}>Your Impact Summary</Text>
          
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text>Carbon Saved:</Text>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>{user.carbonSaved} kg CO₂</Text>
          </View>
          
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text>Total Points:</Text>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>{user.points} pts</Text>
          </View>
          
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text>Habits Completed:</Text>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>{user.completedHabits.length}</Text>
          </View>
          
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text>Current Streak:</Text>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50' }}>5 days</Text>
          </View>
        </View>

        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15 }}>Weekly Progress</Text>
          <Text style={{ color: '#666', marginBottom: 10 }}>📈 Your environmental impact over time</Text>
          <Text style={{ color: '#666', fontStyle: 'italic' }}>Chart visualization would go here...</Text>
        </View>
      </ScrollView>
    </View>
  );
}