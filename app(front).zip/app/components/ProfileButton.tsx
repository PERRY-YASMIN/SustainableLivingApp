import { FontAwesome } from '@expo/vector-icons';
import { Text, TouchableOpacity, View } from 'react-native';
import { User } from '../types';

interface ProfileButtonProps {
  user: User | null;
}

export function ProfileButton({ user }: ProfileButtonProps) {
  return (
    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }}>
      <View style={{
        width: 35,
        height: 35,
        borderRadius: 20,
        backgroundColor: '#4CAF50',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 5
      }}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>
          {user?.name?.charAt(0) || 'U'}
        </Text>
      </View>
      <FontAwesome name="chevron-down" size={12} color="#666" />
    </TouchableOpacity>
  );
}