import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Dimensions, Text, TouchableOpacity, View } from 'react-native';

const { width } = Dimensions.get('window');

const slides = [
  {
    id: '1',
    title: 'Track Eco Habits',
    description: 'Log daily sustainable actions and build green habits',
    color: '#4CAF50',
    icon: '🌱'
  },
  {
    id: '2', 
    title: 'Calculate Carbon Footprint',
    description: 'Understand your environmental impact with smart calculations',
    color: '#2196F3',
    icon: '📊'
  },
  {
    id: '3',
    title: 'Earn Rewards & Badges',
    description: 'Get recognized for your sustainability efforts',
    color: '#FF9800',
    icon: '🏆'
  },
  {
    id: '4',
    title: 'Join Campus Challenges',
    description: 'Compete with friends and make real impact together',
    color: '#9C27B0',
    icon: '👥'
  }
];

export function OnboardingSlides() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const router = useRouter();

  const onNext = () => {
    if (currentIndex < slides.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Complete onboarding
      router.replace('/(tabs)');
    }
  };

  const onSkip = () => {
    router.replace('/(tabs)');
  };

  return (
    <View style={{ flex: 1, backgroundColor: slides[currentIndex].color }}>
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Text style={{ fontSize: 80, marginBottom: 30 }}>{slides[currentIndex].icon}</Text>
        <Text style={{ fontSize: 28, fontWeight: 'bold', color: 'white', textAlign: 'center', marginBottom: 20 }}>
          {slides[currentIndex].title}
        </Text>
        <Text style={{ fontSize: 16, color: 'white', textAlign: 'center', lineHeight: 24 }}>
          {slides[currentIndex].description}
        </Text>
      </View>

      <View style={{ padding: 20 }}>
        {/* Progress Dots */}
        <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 30 }}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: index === currentIndex ? 'white' : 'rgba(255,255,255,0.4)',
                marginHorizontal: 4
              }}
            />
          ))}
        </View>

        {/* Buttons */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <TouchableOpacity onPress={onSkip}>
            <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>Skip</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            onPress={onNext}
            style={{
              backgroundColor: 'white',
              paddingHorizontal: 30,
              paddingVertical: 12,
              borderRadius: 25
            }}
          >
            <Text style={{ color: slides[currentIndex].color, fontSize: 16, fontWeight: 'bold' }}>
              {currentIndex === slides.length - 1 ? 'Get Started' : 'Next'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}