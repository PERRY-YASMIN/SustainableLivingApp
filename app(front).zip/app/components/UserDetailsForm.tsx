import { useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { OnboardingData } from '../types';

interface UserDetailsFormProps {
  onComplete: (data: OnboardingData) => void;
  onSkip: () => void;
}

export function UserDetailsForm({ onComplete, onSkip }: UserDetailsFormProps) {
  const [formData, setFormData] = useState<OnboardingData>({
    name: 'YASMIN',
    campus: 'Karunya University',
    major: '',
    year: '',
    sustainabilityInterest: 'intermediate',
    dailyCommute: 'walking',
    dietaryPreference: 'vegetarian',
    energyHabits: [],
  });

  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: "Welcome to EcoCampus! 🌱",
      description: "Let's personalize your sustainability journey",
      fields: [
        {
          key: 'name' as keyof OnboardingData,
          label: 'Full Name',
          placeholder: 'Enter your full name',
          type: 'text'
        },
        {
          key: 'campus' as keyof OnboardingData,
          label: 'Campus',
          placeholder: 'Enter your campus name',
          type: 'text'
        }
      ]
    },
    {
      title: "Academic Information",
      description: "Tell us about your studies",
      fields: [
        {
          key: 'major' as keyof OnboardingData,
          label: 'Major/Program',
          placeholder: 'e.g., Computer Science, Biology',
          type: 'text'
        },
        {
          key: 'year' as keyof OnboardingData,
          label: 'Academic Year',
          type: 'select',
          options: [
            { label: '1st Year', value: '1st Year' },
            { label: '2nd Year', value: '2nd Year' },
            { label: '3rd Year', value: '3rd Year' },
            { label: '4th Year', value: '4th Year' },
            { label: 'Postgraduate', value: 'Postgraduate' }
          ]
        }
      ]
    },
    {
      title: "Sustainability Profile",
      description: "Help us understand your eco-goals",
      fields: [
        {
          key: 'sustainabilityInterest' as keyof OnboardingData,
          label: 'Sustainability Interest Level',
          type: 'select',
          options: [
            { label: '🌱 Beginner', value: 'beginner' },
            { label: '🌿 Intermediate', value: 'intermediate' },
            { label: '🌳 Advanced', value: 'advanced' },
            { label: '💚 Eco-Expert', value: 'expert' }
          ]
        }
      ]
    },
    {
      title: "Daily Habits",
      description: "Your current lifestyle choices",
      fields: [
        {
          key: 'dailyCommute' as keyof OnboardingData,
          label: 'Daily Commute',
          type: 'select',
          options: [
            { label: '🚶 Walking', value: 'walking' },
            { label: '🚲 Bicycle', value: 'bicycle' },
            { label: '🚌 Public Transport', value: 'public' },
            { label: '🚗 Car', value: 'car' },
            { label: '🚗 Carpool', value: 'carpool' }
          ]
        },
        {
          key: 'dietaryPreference' as keyof OnboardingData,
          label: 'Dietary Preference',
          type: 'select',
          options: [
            { label: '🍖 Omnivore', value: 'omnivore' },
            { label: '🥦 Vegetarian', value: 'vegetarian' },
            { label: '🌱 Vegan', value: 'vegan' },
            { label: '🐟 Pescatarian', value: 'pescatarian' }
          ]
        }
      ]
    },
    {
      title: "Energy Saving Habits",
      description: "Select practices you already follow",
      fields: [
        {
          key: 'energyHabits' as keyof OnboardingData,
          label: 'Energy Saving Habits',
          type: 'multiselect',
          options: [
            { label: '💡 Turn off lights when not in room', value: 'lights_off' },
            { label: '🔌 Unplug electronics when not in use', value: 'unplug_electronics' },
            { label: '🚿 Take shorter showers', value: 'shorter_showers' },
            { label: '❄️ Use AC/Heating efficiently', value: 'efficient_heating' },
            { label: '☀️ Use natural light when possible', value: 'natural_light' }
          ]
        }
      ]
    }
  ];

  const updateField = (key: keyof OnboardingData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete(formData);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const currentStepData = steps[currentStep];

  return (
    <View style={styles.container}>
      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill, 
              { width: `${((currentStep + 1) / steps.length) * 100}%` }
            ]} 
          />
        </View>
        <Text style={styles.progressText}>
          Step {currentStep + 1} of {steps.length}
        </Text>
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>{currentStepData.title}</Text>
        <Text style={styles.description}>{currentStepData.description}</Text>
      </View>

      {/* Form Content */}
      <ScrollView style={styles.formContainer}>
        {currentStepData.fields.map((field, index) => (
          <View key={index} style={styles.fieldContainer}>
            <Text style={styles.fieldLabel}>{field.label}</Text>
            
            {field.type === 'text' && (
              <TextInput
                style={styles.textInput}
                placeholder={field.placeholder}
                value={formData[field.key] as string}
                onChangeText={(text) => updateField(field.key, text)}
                placeholderTextColor="#999"
              />
            )}

            {field.type === 'select' && (
              <View style={styles.optionsContainer}>
                {field.options?.map((option, optIndex) => (
                  <TouchableOpacity
                    key={optIndex}
                    style={[
                      styles.optionButton,
                      formData[field.key] === option.value && styles.optionButtonSelected
                    ]}
                    onPress={() => updateField(field.key, option.value)}
                  >
                    <Text style={[
                      styles.optionText,
                      formData[field.key] === option.value && styles.optionTextSelected
                    ]}>
                      {option.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {field.type === 'multiselect' && (
              <View style={styles.optionsContainer}>
                {field.options?.map((option, optIndex) => {
                  const isSelected = (formData[field.key] as string[]).includes(option.value);
                  return (
                    <TouchableOpacity
                      key={optIndex}
                      style={[
                        styles.optionButton,
                        isSelected && styles.optionButtonSelected
                      ]}
                      onPress={() => {
                        const currentHabits = formData[field.key] as string[];
                        const updatedHabits = isSelected
                          ? currentHabits.filter(h => h !== option.value)
                          : [...currentHabits, option.value];
                        updateField(field.key, updatedHabits);
                      }}
                    >
                      <Text style={[
                        styles.optionText,
                        isSelected && styles.optionTextSelected
                      ]}>
                        {option.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}
          </View>
        ))}
      </ScrollView>

      {/* Navigation Buttons */}
      <View style={styles.buttonContainer}>
        {currentStep > 0 && (
          <TouchableOpacity style={styles.secondaryButton} onPress={prevStep}>
            <Text style={styles.secondaryButtonText}>Back</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity 
          style={[
            styles.primaryButton,
            (!formData.name && currentStep === 0) && styles.primaryButtonDisabled
          ]} 
          onPress={nextStep}
          disabled={!formData.name && currentStep === 0}
        >
          <Text style={styles.primaryButtonText}>
            {currentStep === steps.length - 1 ? 'Get Started!' : 'Continue'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Skip Button */}
      {currentStep === 0 && (
        <TouchableOpacity style={styles.skipButton} onPress={onSkip}>
          <Text style={styles.skipButtonText}>Skip for now</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0f2d',
    padding: 20,
  },
  progressContainer: {
    marginBottom: 30,
  },
  progressBar: {
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 3,
  },
  progressText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    textAlign: 'center',
  },
  header: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    lineHeight: 22,
  },
  formContainer: {
    flex: 1,
  },
  fieldContainer: {
    marginBottom: 25,
  },
  fieldLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: 'white',
    marginBottom: 12,
  },
  textInput: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    borderWidth: 2,
    borderColor: 'transparent',
    color: '#333',
  },
  optionsContainer: {
    gap: 10,
  },
  optionButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  optionButtonSelected: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderColor: '#4CAF50',
  },
  optionText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  optionTextSelected: {
    color: '#4CAF50',
    fontWeight: '600',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginLeft: 10,
  },
  primaryButtonDisabled: {
    backgroundColor: '#cccccc',
  },
  primaryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginRight: 10,
  },
  secondaryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  skipButton: {
    marginTop: 15,
    padding: 12,
    alignItems: 'center',
  },
  skipButtonText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
  },
});