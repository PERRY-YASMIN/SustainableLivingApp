import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import AITipsGenerator from '../../src/components/AITipsGenerator';
import { EcoChallenge } from '../components/EcoChallenge';
import { HabitTracker } from '../components/HabitTracker';
import { Habit, User } from '../types';
import { Storage, defaultHabits, defaultUser } from '../utils/storage';

export default function HomeScreen() {
  const [user, setUser] = useState<User>(defaultUser);
  const [habits, setHabits] = useState<Habit[]>(defaultHabits);
  const router = useRouter();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideUpAnim = useRef(new Animated.Value(30)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;

  useEffect(() => {
    const forceUpdateUserData = async () => {
      await Storage.remove('user');
      await Storage.remove('habits');
      
      const updatedUser = {
        ...defaultUser,
        name: 'Yasmin',
        points: 150,
        carbonSaved: 31,
        badges: ['beginner'],
        completedHabits: []
      };
      
      await Storage.set('user', updatedUser);
      await Storage.set('habits', defaultHabits);
      
      setUser(updatedUser);
      setHabits(defaultHabits);
    };

    forceUpdateUserData();
    
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideUpAnim, {
        toValue: 0,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const updateHabit = async (habitId: string) => {
    const updatedHabits = habits.map(habit => {
      if (habit.id === habitId && !habit.completed) {
        const habitPoints = habit.points;
        const updatedUser: User = {
          ...user,
          points: user.points + habitPoints,
          carbonSaved: user.carbonSaved + (habitPoints * 0.1),
          completedHabits: [...user.completedHabits, habitId]
        };
        
        setUser(updatedUser);
        Storage.set('user', updatedUser);
        
        return { ...habit, completed: true };
      }
      return habit;
    });
    
    setHabits(updatedHabits);
    Storage.set('habits', updatedHabits);
  };

  const navigateWithAnimation = (screen: string) => {
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
    
    setTimeout(() => {
      if (screen === 'profile') {
        router.push('/profile');
      } else if (screen === 'carbon-calculator') {
        router.push('/carbon-calculator');
      } else if (screen === 'sustainability-map') {
        router.push('/sustainability-map');
      } else if (screen === 'rewards') {
        router.push('/rewards');
      } else if (screen === 'nutrition') {
        router.push('/nutrition-tracker');
      }
    }, 200);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      {/* Header */}
      <Animated.View 
        style={{ 
          flexDirection: 'row', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          padding: 20,
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          paddingTop: 50,
          borderBottomLeftRadius: 25,
          borderBottomRightRadius: 25,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 8 },
          shadowOpacity: 0.1,
          shadowRadius: 15,
          elevation: 8,
          opacity: fadeAnim,
          transform: [{ translateY: slideUpAnim }],
          minHeight: 80,
        }}
      >
        <View>
          <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#4CAF50' }}>EcoCampus</Text>
        </View>
        
        <TouchableOpacity 
          onPress={() => navigateWithAnimation('profile')}
          style={{
            shadowColor: '#4CAF50',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 5,
          }}
        >
          <Animated.View style={{
            width: 45,
            height: 45,
            borderRadius: 22.5,
            backgroundColor: '#4CAF50',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <Ionicons name="person" size={22} color="white" />
          </Animated.View>
        </TouchableOpacity>
      </Animated.View>
      
      <ScrollView style={{ flex: 1, padding: 15 }} showsVerticalScrollIndicator={false}>
        {/* 1. Personalized Welcome Section */}
        <Animated.View 
          style={{ 
            backgroundColor: '#4CAF50',
            padding: 25, 
            borderRadius: 20, 
            marginBottom: 20,
            shadowColor: '#4CAF50',
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.4,
            shadowRadius: 15,
            elevation: 10,
            opacity: fadeAnim,
            transform: [{ translateY: slideUpAnim }],
          }}
        >
          <Text style={{ fontSize: 22, fontWeight: 'bold', color: 'white', marginBottom: 8 }}>
            Hello, {user.name}! 👋
          </Text>
          <Text style={{ color: 'rgba(255, 255, 255, 0.9)', fontSize: 16, lineHeight: 22 }}>
            🌱 You've saved <Text style={{ fontWeight: 'bold' }}>{user.carbonSaved} kg CO₂</Text>
            {' • '}⭐ <Text style={{ fontWeight: 'bold' }}>{user.points} points</Text>
          </Text>
          
          <View style={{ marginTop: 15, backgroundColor: 'rgba(255, 255, 255, 0.2)', height: 6, borderRadius: 3, overflow: 'hidden' }}>
            <View 
              style={{
                height: '100%',
                backgroundColor: 'white',
                width: `${(user.points / 500) * 100}%`,
                borderRadius: 3,
              }}
            />
          </View>
          <Text style={{ color: 'rgba(255, 255, 255, 0.8)', fontSize: 12, marginTop: 8 }}>
            {500 - user.points} points until next reward
          </Text>
        </Animated.View>

        {/* 2. Weekly Challenge */}
        <Animated.View 
          style={{ 
            opacity: fadeAnim, 
            transform: [{ translateY: slideUpAnim }],
            marginBottom: 20,
          }}
        >
          <EcoChallenge challenge={{
            id: '1',
            name: 'Plastic Free Week',
            description: 'Avoid single-use plastics for 7 days',
            duration: 7,
            participants: 42
          }} />
        </Animated.View>

        {/* 3. Features Grid */}
        <Animated.View 
          style={{ 
            opacity: fadeAnim,
            transform: [{ translateY: slideUpAnim }],
            marginBottom: 20,
          }}
        >
          {/* First Row */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 }}>
            <TouchableOpacity 
              onPress={() => navigateWithAnimation('carbon-calculator')}
              style={{ 
                backgroundColor: '#4CAF50', 
                padding: 20, 
                borderRadius: 15, 
                flex: 1, 
                marginRight: 8,
                shadowColor: '#4CAF50',
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.4,
                shadowRadius: 12,
                elevation: 8,
              }}
            >
              <View style={{ alignItems: 'center' }}>
                <Ionicons name="calculator" size={28} color="white" />
                <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', marginTop: 8, fontSize: 14 }}>
                  Carbon Calculator
                </Text>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              onPress={() => navigateWithAnimation('sustainability-map')}
              style={{ 
                backgroundColor: '#2196F3', 
                padding: 20, 
                borderRadius: 15, 
                flex: 1, 
                marginLeft: 8,
                shadowColor: '#2196F3',
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.4,
                shadowRadius: 12,
                elevation: 8,
              }}
            >
              <View style={{ alignItems: 'center' }}>
                <Ionicons name="map" size={28} color="white" />
                <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', marginTop: 8, fontSize: 14 }}>
                  Campus Map
                </Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Second Row */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <TouchableOpacity 
              onPress={() => navigateWithAnimation('rewards')}
              style={{ 
                backgroundColor: '#FF9800', 
                padding: 20, 
                borderRadius: 15, 
                flex: 1, 
                marginRight: 8,
                shadowColor: '#FF9800',
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.4,
                shadowRadius: 12,
                elevation: 8,
              }}
            >
              <View style={{ alignItems: 'center' }}>
                <Ionicons name="gift" size={28} color="white" />
                <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', marginTop: 8, fontSize: 14 }}>
                  Rewards
                </Text>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity 
              onPress={() => navigateWithAnimation('nutrition')}
              style={{ 
                backgroundColor: '#FF5722', 
                padding: 20, 
                borderRadius: 15, 
                flex: 1, 
                marginLeft: 8,
                shadowColor: '#FF5722',
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.4,
                shadowRadius: 12,
                elevation: 8,
              }}
            >
              <View style={{ alignItems: 'center' }}>
                <Ionicons name="nutrition" size={28} color="white" />
                <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold', marginTop: 8, fontSize: 14 }}>
                  Nutrition
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </Animated.View>

        {/* 4. AI Sustainability Coach */}
        <Animated.View style={{ 
          opacity: fadeAnim, 
          transform: [{ translateY: slideUpAnim }],
          marginBottom: 20,
        }}>
          <AITipsGenerator />
        </Animated.View>

        {/* 5. Daily Habits Tracker */}
        <Animated.View style={{ 
          opacity: fadeAnim, 
          transform: [{ translateY: slideUpAnim }],
          marginBottom: 20,
        }}>
          <HabitTracker habits={habits} onUpdateHabit={updateHabit} />
        </Animated.View>

        {/* 6. Inspirational Quote */}
        <Animated.View 
          style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            padding: 20,
            borderRadius: 15,
            borderLeftWidth: 4,
            borderLeftColor: '#4CAF50',
            opacity: fadeAnim,
            transform: [{ translateY: slideUpAnim }],
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#ffffff', fontSize: 14, fontStyle: 'italic', lineHeight: 20 }}>
            "The greatest threat to our planet is the belief that someone else will save it." 
          </Text>
          <Text style={{ color: '#4CAF50', fontSize: 12, fontWeight: 'bold', marginTop: 8 }}>
            - Robert Swan
          </Text>
        </Animated.View>
      </ScrollView>
    </View>
  );
}