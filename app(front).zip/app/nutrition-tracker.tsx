import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { defaultMeals, foodDatabase, FoodItem, Meal, MealType, Storage } from './utils/storage';

type NutritionSummary = {
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  healthyMeals: number;
  mealCount: number;
};

export default function NutritionTrackerScreen() {
  const router = useRouter();
  const [meals, setMeals] = useState<Meal[]>(defaultMeals);
  const [selectedMealType, setSelectedMealType] = useState<MealType>('breakfast');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFoods, setSelectedFoods] = useState<FoodItem[]>([]);

  useEffect(() => {
    loadMeals();
  }, []);

  const loadMeals = async () => {
    const savedMeals = await Storage.get('nutritionMeals');
    if (savedMeals) {
      // Convert timestamp strings back to Date objects
      const mealsWithProperDates = savedMeals.map((meal: any) => ({
        ...meal,
        timestamp: new Date(meal.timestamp)
      }));
      setMeals(mealsWithProperDates);
    }
  };

  const calculateNutritionSummary = (): NutritionSummary => {
    return meals.reduce((summary, meal) => ({
      totalCalories: summary.totalCalories + meal.totalCalories,
      totalProtein: summary.totalProtein + meal.totalProtein,
      totalCarbs: summary.totalCarbs + meal.totalCarbs,
      totalFats: summary.totalFats + meal.totalFats,
      healthyMeals: summary.healthyMeals + (meal.isHealthy ? 1 : 0),
      mealCount: summary.mealCount + 1
    }), {
      totalCalories: 0,
      totalProtein: 0,
      totalCarbs: 0,
      totalFats: 0,
      healthyMeals: 0,
      mealCount: 0
    });
  };

  const filteredFoods = foodDatabase.filter(food =>
    food.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const addFoodToMeal = (food: FoodItem) => {
    setSelectedFoods([...selectedFoods, food]);
    setSearchQuery('');
  };

  const removeFoodFromMeal = (foodId: string) => {
    setSelectedFoods(selectedFoods.filter(food => food.id !== foodId));
  };

  const saveMeal = async () => {
    if (selectedFoods.length === 0) {
      Alert.alert('Error', 'Please add at least one food item to your meal');
      return;
    }

    const totalCalories = selectedFoods.reduce((sum, food) => sum + food.calories, 0);
    const totalProtein = selectedFoods.reduce((sum, food) => sum + food.protein, 0);
    const totalCarbs = selectedFoods.reduce((sum, food) => sum + food.carbs, 0);
    const totalFats = selectedFoods.reduce((sum, food) => sum + food.fats, 0);

    const newMeal: Meal = {
      id: Date.now().toString(),
      type: selectedMealType,
      foods: [...selectedFoods],
      timestamp: new Date(), // This is a proper Date object
      totalCalories,
      totalProtein,
      totalCarbs,
      totalFats,
      isHealthy: checkIfHealthy(totalCalories, totalProtein, totalFats)
    };

    const updatedMeals = [newMeal, ...meals];
    setMeals(updatedMeals);
    setSelectedFoods([]);
    
    // Save to storage (timestamp will be converted to string automatically)
    await Storage.set('nutritionMeals', updatedMeals);
    
    Alert.alert('Success', `${selectedMealType.charAt(0).toUpperCase() + selectedMealType.slice(1)} saved successfully!`);
  };

  const checkIfHealthy = (calories: number, protein: number, fats: number): boolean => {
    return calories < 800 && protein > 10 && fats < 30;
  };

  const getHealthRecommendation = () => {
    const summary = calculateNutritionSummary();
    if (summary.totalCalories < 1200) return 'Consider adding more nutrient-dense foods';
    if (summary.totalCalories > 2500) return 'Try to balance your calorie intake';
    if (summary.totalProtein < 50) return 'Include more protein-rich foods';
    if (summary.mealCount > 0 && summary.healthyMeals / summary.mealCount < 0.5) return 'Try to include more balanced meals';
    return 'Great balance! Keep it up!';
  };

  const summary = calculateNutritionSummary();

  // Safe timestamp display function
  const formatTime = (timestamp: Date) => {
    if (!timestamp || !(timestamp instanceof Date)) {
      return 'Unknown time';
    }
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      {/* Header */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        paddingTop: 60,
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#4CAF50' }}>Nutrition Tracker</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 15 }} showsVerticalScrollIndicator={false}>
        {/* Nutrition Summary */}
        <View style={{ 
          backgroundColor: '#4CAF50',
          padding: 20, 
          borderRadius: 20, 
          marginBottom: 20,
        }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'white', marginBottom: 15 }}>
            Today's Nutrition
          </Text>
          
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap' }}>
            <View style={{ alignItems: 'center', marginBottom: 10, width: '48%' }}>
              <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white' }}>{summary.totalCalories}</Text>
              <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12 }}>Calories</Text>
            </View>
            <View style={{ alignItems: 'center', marginBottom: 10, width: '48%' }}>
              <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white' }}>{summary.totalProtein}g</Text>
              <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12 }}>Protein</Text>
            </View>
            <View style={{ alignItems: 'center', marginBottom: 10, width: '48%' }}>
              <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white' }}>{summary.totalCarbs}g</Text>
              <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12 }}>Carbs</Text>
            </View>
            <View style={{ alignItems: 'center', marginBottom: 10, width: '48%' }}>
              <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white' }}>{summary.totalFats}g</Text>
              <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12 }}>Fats</Text>
            </View>
          </View>

          <View style={{ 
            backgroundColor: 'rgba(255,255,255,0.2)', 
            padding: 15, 
            borderRadius: 10, 
            marginTop: 10 
          }}>
            <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
              💡 {getHealthRecommendation()}
            </Text>
          </View>
        </View>

        {/* Meal Selection & Food Adding Section */}
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          padding: 20,
          borderRadius: 15,
          marginBottom: 20,
        }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
            Select Meal Type
          </Text>

          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
            {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((mealType) => (
              <TouchableOpacity
                key={mealType}
                onPress={() => setSelectedMealType(mealType)}
                style={{
                  backgroundColor: selectedMealType === mealType ? '#4CAF50' : '#f0f0f0',
                  padding: 15,
                  borderRadius: 10,
                  marginBottom: 10,
                  width: '48%',
                  alignItems: 'center',
                }}
              >
                <Text style={{ 
                  color: selectedMealType === mealType ? 'white' : '#666',
                  fontWeight: 'bold',
                  textTransform: 'capitalize'
                }}>
                  {mealType}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Food Search */}
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginTop: 15, marginBottom: 10 }}>
            Search and Add Foods
          </Text>

          <TextInput
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 10,
              borderWidth: 1,
              borderColor: '#ddd',
            }}
            placeholder="Search for foods (apple, chicken, etc.)"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />

          {/* Selected Foods */}
          {selectedFoods.length > 0 && (
            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontSize: 14, fontWeight: 'bold', color: '#333', marginBottom: 10 }}>
                Selected Foods:
              </Text>
              {selectedFoods.map((food) => (
                <View key={food.id} style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  backgroundColor: '#E8F5E8',
                  padding: 10,
                  borderRadius: 8,
                  marginBottom: 5,
                }}>
                  <Text style={{ flex: 1, color: '#333' }}>{food.name}</Text>
                  <Text style={{ color: '#666', marginRight: 10 }}>
                    {food.calories} cal
                  </Text>
                  <TouchableOpacity onPress={() => removeFoodFromMeal(food.id)}>
                    <Ionicons name="close-circle" size={20} color="#ff4444" />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}

          {/* Food Suggestions */}
          {searchQuery && (
            <View style={{ maxHeight: 200 }}>
              {filteredFoods.map((food) => (
                <TouchableOpacity
                  key={food.id}
                  onPress={() => addFoodToMeal(food)}
                  style={{
                    backgroundColor: 'white',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 5,
                    borderWidth: 1,
                    borderColor: '#eee',
                  }}
                >
                  <Text style={{ fontWeight: 'bold', color: '#333' }}>{food.name}</Text>
                  <Text style={{ color: '#666', fontSize: 12 }}>
                    {food.calories} cal • P: {food.protein}g • C: {food.carbs}g • F: {food.fats}g
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <TouchableOpacity 
            onPress={saveMeal}
            style={{
              backgroundColor: '#4CAF50',
              padding: 15,
              borderRadius: 10,
              alignItems: 'center',
              marginTop: 15,
            }}
          >
            <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>
              Save {selectedMealType.charAt(0).toUpperCase() + selectedMealType.slice(1)}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Meal History */}
        <View style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          padding: 20,
          borderRadius: 15,
        }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
            Today's Meals ({meals.length})
          </Text>

          {meals.length === 0 ? (
            <Text style={{ color: '#666', textAlign: 'center', padding: 20 }}>
              No meals logged today. Add your first meal!
            </Text>
          ) : (
            meals.map((meal) => (
              <View 
                key={meal.id}
                style={{
                  backgroundColor: meal.isHealthy ? '#E8F5E8' : '#FFF3E0',
                  padding: 15,
                  borderRadius: 10,
                  marginBottom: 10,
                  borderLeftWidth: 4,
                  borderLeftColor: meal.isHealthy ? '#4CAF50' : '#FF9800',
                }}
              >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={{ fontWeight: 'bold', color: '#333', fontSize: 16, textTransform: 'capitalize' }}>
                    {meal.type}
                  </Text>
                  <Text style={{ color: '#666', fontSize: 12 }}>
                    {formatTime(meal.timestamp)}
                  </Text>
                </View>
                
                <View style={{ marginTop: 8 }}>
                  <Text style={{ color: '#666', fontSize: 12, marginBottom: 5 }}>
                    Foods: {meal.foods.map(f => f.name).join(', ')}
                  </Text>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={{ color: '#666', fontSize: 12 }}>{meal.totalCalories} cal</Text>
                    <Text style={{ color: '#666', fontSize: 12 }}>P: {meal.totalProtein}g</Text>
                    <Text style={{ color: '#666', fontSize: 12 }}>C: {meal.totalCarbs}g</Text>
                    <Text style={{ color: '#666', fontSize: 12 }}>F: {meal.totalFats}g</Text>
                  </View>
                </View>
                
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 5 }}>
                  <Ionicons 
                    name={meal.isHealthy ? "checkmark-circle" : "nutrition"} 
                    size={16} 
                    color={meal.isHealthy ? '#4CAF50' : '#FF9800'} 
                  />
                  <Text style={{ 
                    color: meal.isHealthy ? '#4CAF50' : '#FF9800', 
                    fontSize: 12, 
                    marginLeft: 5,
                    fontWeight: '500'
                  }}>
                    {meal.isHealthy ? 'Healthy Choice' : 'Moderate Choice'}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}