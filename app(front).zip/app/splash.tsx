// app/splash.tsx
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useRef } from 'react';
import { Animated, Easing, Text, TouchableOpacity, View } from 'react-native';
import { Storage } from './utils/storage';

export default function SplashScreen() {
  const router = useRouter();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.5)).current;

  useEffect(() => {
    // Clear any existing user data to ensure fresh start
    const clearData = async () => {
      console.log('Clearing existing user data...');
      await Storage.remove('user');
    };
    
    clearData();

    // Simple animation without complex sequences
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1500,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();

    // ALWAYS go to signin first (for testing)
    const timer = setTimeout(() => {
      console.log('Splash screen completed, going to signin');
      router.replace('/signin');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <TouchableOpacity 
      style={{ flex: 1, backgroundColor: '#0a0a0a' }} 
      activeOpacity={0.9}
      onPress={() => {
        console.log('Splash screen tapped, going to signin');
        router.replace('/signin');
      }}
    >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Animated.View 
          style={{
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }],
            marginBottom: 40,
          }}
        >
          <View style={{
            width: 120,
            height: 120,
            borderRadius: 60,
            backgroundColor: '#4CAF50',
            justifyContent: 'center',
            alignItems: 'center',
            shadowColor: '#4CAF50',
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: 0.5,
            shadowRadius: 20,
            elevation: 10,
          }}>
            <Ionicons name="leaf" size={60} color="white" />
          </View>
        </Animated.View>

        <Animated.Text 
          style={{
            fontSize: 42,
            fontWeight: 'bold',
            color: '#4CAF50',
            textAlign: 'center',
            opacity: fadeAnim,
            marginBottom: 10,
            textShadowColor: 'rgba(76, 175, 80, 0.3)',
            textShadowOffset: { width: 0, height: 0 },
            textShadowRadius: 10,
          }}
        >
          EcoCampus
        </Animated.Text>

        <Animated.Text 
          style={{
            fontSize: 18,
            color: '#ffffff',
            textAlign: 'center',
            opacity: fadeAnim,
            marginBottom: 40,
          }}
        >
          Your Sustainable Campus Journey
        </Animated.Text>

        <View style={{ flexDirection: 'row', marginBottom: 20 }}>
          {[0, 1, 2].map((index) => (
            <View
              key={index}
              style={{
                width: 10,
                height: 10,
                borderRadius: 5,
                backgroundColor: '#4CAF50',
                marginHorizontal: 5,
              }}
            />
          ))}
        </View>

        <Text style={{ fontSize: 14, color: '#666', textAlign: 'center' }}>
          Tap anywhere to continue
        </Text>
      </View>
    </TouchableOpacity>
  );
}