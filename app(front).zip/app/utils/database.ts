// Temporary mock database until Firebase is properly set up

export interface MockUser {
  id: string;
  name: string;
  campus: string;
  points: number;
  badges: string[];
  carbonSaved: number;
}

export interface MockHabit {
  id: string;
  name: string;
  completed: boolean;
  points: number;
}

// Mock data
const mockUser: MockUser = {
  id: '1',
  name: 'Eco Warrior',
  campus: 'Main Campus',
  points: 150,
  badges: ['beginner'],
  carbonSaved: 25.5
};

const mockHabits: MockHabit[] = [
  { id: '1', name: 'Used reusable bottle', completed: false, points: 10 },
  { id: '2', name: 'Walked instead of driving', completed: false, points: 15 },
  { id: '3', name: 'Reduced electricity use', completed: false, points: 10 },
  { id: '4', name: 'Recycled properly', completed: false, points: 8 },
  { id: '5', name: 'Meat-free meal', completed: false, points: 12 }
];

// Mock functions
export const saveUserData = async (userId: string, userData: Partial<MockUser>) => {
  console.log('Mock: Saving user data', userData);
  return Promise.resolve();
};

export const getUserData = async (userId: string): Promise<MockUser | null> => {
  console.log('Mock: Getting user data for', userId);
  return Promise.resolve(mockUser);
};

export const updateUserPoints = async (userId: string, pointsToAdd: number) => {
  console.log('Mock: Updating points', pointsToAdd);
  return Promise.resolve({ newPoints: mockUser.points + pointsToAdd, newCarbonSaved: mockUser.carbonSaved + (pointsToAdd * 0.1) });
};

export const saveUserHabits = async (userId: string, habits: MockHabit[]) => {
  console.log('Mock: Saving habits');
  return Promise.resolve();
};

export const getUserHabits = async (userId: string): Promise<MockHabit[]> => {
  console.log('Mock: Getting habits');
  return Promise.resolve(mockHabits);
};

export const getChallenges = async () => {
  return Promise.resolve([{
    id: '1',
    name: 'Plastic Free Week',
    description: 'Avoid single-use plastics for 7 days',
    duration: 7,
    participants: 42
  }]);
};

export const signInUser = async () => {
  return Promise.resolve({ uid: 'mock-user-id' });
};

export const auth = {
  currentUser: { uid: 'mock-user-id' }
};

// Make sure this function is properly exported
export const onAuthStateChanged = (auth: any, callback: any) => {
  // Immediately call the callback with a mock user
  callback({ uid: 'mock-user-id' });
  return () => {}; // unsubscribe function
};