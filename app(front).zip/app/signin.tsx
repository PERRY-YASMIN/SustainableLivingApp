// app/signin.tsx
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Storage } from './utils/storage';

export default function SigninScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSignin = async () => {
    if (isLoading) return;
    
    setIsLoading(true);
    
    // Wait a bit to show the loading state
    setTimeout(async () => {
      // Create a basic user WITHOUT major field
      const userData = {
        id: '1',
        name: '', // Empty - will be filled in user details
        email: email || 'user@campus.edu',
        points: 0,
        carbonSaved: 0,
        habits: [],
        badges: [],
        completedHabits: [],
        // NO major field - this will trigger user details
      };

      await Storage.set('user', userData);
      setIsLoading(false);
      console.log('Signin completed, navigating to user details');
      router.replace('/user-details');
    }, 1000);
  };

  const handleGuest = async () => {
    if (isLoading) return;
    
    setIsLoading(true);
    
    setTimeout(async () => {
      // Create guest user
      const guestData = {
        id: 'guest',
        name: '',
        email: '',
        points: 0,
        carbonSaved: 0,
        habits: [],
        badges: [],
        completedHabits: [],
      };

      await Storage.set('user', guestData);
      setIsLoading(false);
      console.log('Guest mode, navigating to user details');
      router.replace('/user-details');
    }, 1000);
  };

  return (
    <KeyboardAvoidingView 
      style={{ flex: 1, backgroundColor: '#0a0f2d' }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Welcome to EcoCampus</Text>
          <Text style={styles.subtitle}>Sign in to start your sustainability journey</Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Email address"
            placeholderTextColor="#999"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#999"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity 
            style={[styles.signinButton, isLoading && styles.buttonDisabled]} 
            onPress={handleSignin}
            disabled={isLoading}
          >
            <Text style={styles.signinButtonText}>
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.guestButton, isLoading && styles.buttonDisabled]} 
            onPress={handleGuest}
            disabled={isLoading}
          >
            <Text style={styles.guestButtonText}>
              {isLoading ? 'Please wait...' : 'Continue as Guest'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Don't have an account?{' '}
            <Text style={styles.linkText}>Sign Up</Text>
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 50,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
  },
  form: {
    marginBottom: 30,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    color: '#333',
    marginBottom: 15,
  },
  signinButton: {
    backgroundColor: '#4CAF50',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonDisabled: {
    backgroundColor: '#cccccc',
  },
  signinButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  guestButton: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  guestButtonText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 16,
  },
  footer: {
    alignItems: 'center',
  },
  footerText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
  },
  linkText: {
    color: '#4CAF50',
    fontWeight: '600',
  },
});