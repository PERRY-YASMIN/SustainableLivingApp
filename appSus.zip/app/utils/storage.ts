import AsyncStorage from '@react-native-async-storage/async-storage';
import { Habit, User } from '../types';

export const Storage = {
  set: async (key: string, value: any) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.log('Storage set error:', error);
    }
  },

  get: async (key: string) => {
    try {
      const value = await AsyncStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      console.log('Storage get error:', error);
      return null;
    }
  },

  remove: async (key: string) => {
    try {
      await AsyncStorage.removeItem(key);
    } catch (error) {
      console.log('Storage remove error:', error);
    }
  }
};

export const defaultUser: User = {
  id: '1',
  name: 'YASMIN', // CHANGED TO YASMIN
  campus: 'Karunya University',
  points: 325,
  badges: ['eco-warrior', 'water-saver', 'green-commuter'],
  carbonSaved: 42.7,
  completedHabits: ['1', '3', '4']
};

export const defaultHabits: Habit[] = [
  { id: '1', name: 'Used reusable bottle', completed: true, points: 10 },
  { id: '2', name: 'Walked instead of driving', completed: false, points: 15 },
  { id: '3', name: 'Reduced electricity use', completed: true, points: 10 },
  { id: '4', name: 'Recycled properly', completed: true, points: 8 },
  { id: '5', name: 'Meat-free meal', completed: false, points: 12 }
];

// Leaderboard data
export const leaderboardData = [
  { id: '1', name: 'YASMIN', points: 325, carbonSaved: 42.7, rank: 1, avatar: '👑' },
  { id: '2', name: 'AMY', points: 298, carbonSaved: 38.2, rank: 2, avatar: '🌟' },
  { id: '3', name: 'SAM', points: 275, carbonSaved: 35.1, rank: 3, avatar: '⭐' },
  { id: '4', name: 'PRIYA', points: 240, carbonSaved: 30.8, rank: 4, avatar: '💚' },
  { id: '5', name: 'JORDAN', points: 215, carbonSaved: 27.9, rank: 5, avatar: '🌱' },
];

export default { Storage, defaultUser, defaultHabits, leaderboardData };