export const calculateCarbonFootprint = (userData: any) => {
  // Transport emissions (kg CO2 per week)
  const transportEmissions = {
    car: 140,    // 20km daily * 7 days * 0.2kg CO2 per km
    bus: 35,     // 20km daily * 7 days * 0.05kg CO2 per km
    bike: 0,
    walk: 0
  };

  // Diet emissions (kg CO2 per week)
  const dietEmissions = {
    meat: 105,   // 15kg CO2 per week for meat diet
    vegetarian: 42, // 6kg CO2 per week for vegetarian
    vegan: 21    // 3kg CO2 per week for vegan
  };

  // Energy emissions (kg CO2 per kWh * weekly usage)
  const energyEmissions = userData.energy * 0.5; // 0.5 kg CO2 per kWh

  const transportScore = transportEmissions[userData.transport as keyof typeof transportEmissions] || 0;
  const dietScore = dietEmissions[userData.diet as keyof typeof dietEmissions] || 0;
  
  return Math.round(transportScore + dietScore + energyEmissions);
};

export const calculatePoints = (habitsCompleted: number, carbonSaved: number) => {
  const habitPoints = habitsCompleted * 10;
  const carbonPoints = Math.round(carbonSaved * 2); // 2 points per kg CO2 saved
  return habitPoints + carbonPoints;
};

export const calculateCarbonSaved = (userData: any, baselineData: any) => {
  // Calculate difference from baseline (average user)
  const baselineFootprint = calculateCarbonFootprint(baselineData);
  const userFootprint = calculateCarbonFootprint(userData);
  return Math.max(0, baselineFootprint - userFootprint);
};