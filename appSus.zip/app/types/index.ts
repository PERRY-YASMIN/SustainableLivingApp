export interface User {
  id: string;
  name: string;
  campus: string;
  points: number;
  badges: string[];
  carbonSaved: number;
  completedHabits: string[];
}

export interface Habit {
  id: string;
  name: string;
  completed: boolean;
  points: number;
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  duration: number;
  participants: number;
}

export interface LeaderboardUser {
  id: string;
  name: string;
  points: number;
  carbonSaved: number;
  rank: number;
  avatar: string;
}