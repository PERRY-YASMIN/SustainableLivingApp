import { Ionicons } from '@expo/vector-icons';
import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { User } from './../types';
import { Storage, defaultUser, leaderboardData } from './../utils/storage';

export default function ExploreScreen() {
  const [user, setUser] = useState<User>(defaultUser);
  const [leaderboard, setLeaderboard] = useState(leaderboardData);
  const [activeTab, setActiveTab] = useState('stats');

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    loadUserData();
    
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const loadUserData = async () => {
    const savedUser = await Storage.get('user');
    if (savedUser) setUser(savedUser);
  };

  const getRankColor = (rank: number) => {
    switch(rank) {
      case 1: return '#FFD700';
      case 2: return '#C0C0C0';
      case 3: return '#CD7F32';
      default: return '#4CAF50';
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d', paddingTop: 60 }}>
      <ScrollView style={{ flex: 1, padding: 20 }} showsVerticalScrollIndicator={false}>
        <Animated.View style={{ 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}>
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 30 }}>
            <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#4CAF50', textAlign: 'center' }}>
              Eco Dashboard
            </Text>
            <Text style={{ fontSize: 16, color: '#8892b0', textAlign: 'center', marginTop: 8 }}>
              Your sustainability journey, {user.name}! 🌟
            </Text>
          </View>

          {/* Tab Navigation */}
          <View style={{ 
            flexDirection: 'row', 
            backgroundColor: 'rgba(255, 255, 255, 0.1)', 
            borderRadius: 15, 
            padding: 5,
            marginBottom: 20,
          }}>
            <TouchableOpacity
              style={{
                flex: 1,
                padding: 12,
                borderRadius: 10,
                backgroundColor: activeTab === 'stats' ? '#4CAF50' : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab('stats')}
            >
              <Text style={{ 
                color: activeTab === 'stats' ? 'white' : '#8892b0', 
                fontWeight: '600',
                fontSize: 14,
              }}>
                📊 Stats
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flex: 1,
                padding: 12,
                borderRadius: 10,
                backgroundColor: activeTab === 'leaderboard' ? '#4CAF50' : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab('leaderboard')}
            >
              <Text style={{ 
                color: activeTab === 'leaderboard' ? 'white' : '#8892b0', 
                fontWeight: '600',
                fontSize: 14,
              }}>
                🏆 Leaderboard
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flex: 1,
                padding: 12,
                borderRadius: 10,
                backgroundColor: activeTab === 'achievements' ? '#4CAF50' : 'transparent',
                alignItems: 'center',
              }}
              onPress={() => setActiveTab('achievements')}
            >
              <Text style={{ 
                color: activeTab === 'achievements' ? 'white' : '#8892b0', 
                fontWeight: '600',
                fontSize: 14,
              }}>
                🎯 Achievements
              </Text>
            </TouchableOpacity>
          </View>

          {activeTab === 'stats' && (
            <>
              {/* Impact Summary */}
              <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 25, borderRadius: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: '#1a1a1a', textAlign: 'center' }}>
                  Your Impact Summary
                </Text>
                
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 }}>
                  <View style={{ alignItems: 'center', flex: 1 }}>
                    <View style={{ 
                      width: 70, 
                      height: 70, 
                      borderRadius: 35, 
                      backgroundColor: '#E8F5E8', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      marginBottom: 8,
                    }}>
                      <Ionicons name="leaf" size={30} color="#4CAF50" />
                    </View>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>{user.carbonSaved}</Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>kg CO₂ Saved</Text>
                  </View>
                  
                  <View style={{ alignItems: 'center', flex: 1 }}>
                    <View style={{ 
                      width: 70, 
                      height: 70, 
                      borderRadius: 35, 
                      backgroundColor: '#E3F2FD', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      marginBottom: 8,
                    }}>
                      <Ionicons name="trophy" size={30} color="#2196F3" />
                    </View>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#2196F3' }}>{user.points}</Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>Total Points</Text>
                  </View>
                  
                  <View style={{ alignItems: 'center', flex: 1 }}>
                    <View style={{ 
                      width: 70, 
                      height: 70, 
                      borderRadius: 35, 
                      backgroundColor: '#FFF3E0', 
                      justifyContent: 'center', 
                      alignItems: 'center',
                      marginBottom: 8,
                    }}>
                      <Ionicons name="flash" size={30} color="#FF9800" />
                    </View>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#FF9800' }}>7</Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>Day Streak</Text>
                  </View>
                </View>

                {/* Weekly Progress */}
                <View style={{ marginTop: 15 }}>
                  <Text style={{ fontWeight: 'bold', color: '#333', marginBottom: 10 }}>Weekly Progress</Text>
                  <View style={{ backgroundColor: '#f0f0f0', height: 8, borderRadius: 4, overflow: 'hidden' }}>
                    <View style={{ 
                      height: '100%', 
                      backgroundColor: '#4CAF50', 
                      width: '75%',
                      borderRadius: 4,
                    }} />
                  </View>
                  <Text style={{ color: '#666', fontSize: 12, marginTop: 5 }}>75% of weekly goals completed</Text>
                </View>
              </View>

              {/* Environmental Impact */}
              <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 25, borderRadius: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Environmental Impact</Text>
                
                <View style={{ backgroundColor: '#E8F5E8', padding: 15, borderRadius: 12, marginBottom: 10 }}>
                  <Text style={{ color: '#2E7D32', fontWeight: '600', marginBottom: 5 }}>🌳 Equivalent to planting {Math.round(user.carbonSaved / 21)} trees</Text>
                  <Text style={{ color: '#4CAF50', fontSize: 12 }}>One tree absorbs ~21 kg CO₂ per year</Text>
                </View>
                
                <View style={{ backgroundColor: '#E3F2FD', padding: 15, borderRadius: 12, marginBottom: 10 }}>
                  <Text style={{ color: '#1976D2', fontWeight: '600', marginBottom: 5 }}>🚗 Equivalent to not driving {Math.round(user.carbonSaved / 0.4)} km</Text>
                  <Text style={{ color: '#2196F3', fontSize: 12 }}>Average car emits ~0.4 kg CO₂ per km</Text>
                </View>
                
                <View style={{ backgroundColor: '#FFF3E0', padding: 15, borderRadius: 12 }}>
                  <Text style={{ color: '#FF9800', fontWeight: '600', marginBottom: 5 }}>💡 Equivalent to saving {Math.round(user.carbonSaved * 12)} kWh of electricity</Text>
                  <Text style={{ color: '#FF9800', fontSize: 12 }}>1 kWh produces ~0.5 kg CO₂</Text>
                </View>
              </View>

              {/* Recent Activity */}
              <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 25, borderRadius: 20 }}>
                <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Recent Activity</Text>
                
                {[
                  { action: 'Completed "Recycled properly"', points: '+8', time: '2 hours ago', icon: '♻️' },
                  { action: 'Used water refill station', points: '+5', time: 'Yesterday', icon: '💧' },
                  { action: '7-day streak bonus', points: '+25', time: '2 days ago', icon: '🔥' },
                  { action: 'Plastic-free challenge', points: '+15', time: '3 days ago', icon: '🌱' },
                ].map((activity, index) => (
                  <View key={index} style={{ 
                    flexDirection: 'row', 
                    alignItems: 'center', 
                    paddingVertical: 12,
                    borderBottomWidth: index < 3 ? 1 : 0,
                    borderBottomColor: '#f0f0f0',
                  }}>
                    <Text style={{ fontSize: 20, marginRight: 12 }}>{activity.icon}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontWeight: '600', color: '#333' }}>{activity.action}</Text>
                      <Text style={{ color: '#666', fontSize: 12 }}>{activity.time}</Text>
                    </View>
                    <Text style={{ color: '#4CAF50', fontWeight: 'bold' }}>{activity.points}</Text>
                  </View>
                ))}
              </View>
            </>
          )}

          {activeTab === 'leaderboard' && (
            <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 25, borderRadius: 20 }}>
              <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: '#1a1a1a', textAlign: 'center' }}>
                Eco Warriors Leaderboard
              </Text>
              <Text style={{ color: '#666', textAlign: 'center', marginBottom: 20 }}>
                Top sustainability champions this month
              </Text>

              {leaderboard.map((player, index) => (// error at:player, index
                <View
                  key={player.id}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 15,
                    backgroundColor: player.name === 'YASMIN' ? '#E8F5E8' : '#f8f9fa',
                    borderRadius: 12,
                    marginBottom: 10,
                    borderWidth: player.name === 'YASMIN' ? 2 : 0,
                    borderColor: '#4CAF50',
                  }}
                >
                  <View style={{ 
                    width: 40, 
                    height: 40, 
                    borderRadius: 20, 
                    backgroundColor: getRankColor(player.rank),
                    justifyContent: 'center', 
                    alignItems: 'center',
                    marginRight: 15,
                  }}>
                    <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>
                      {player.rank}
                    </Text>
                  </View>
                  
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                      <Text style={{ fontSize: 18, marginRight: 8 }}>{player.avatar}</Text>
                      <Text style={{ 
                        fontSize: 16, 
                        fontWeight: 'bold', 
                        color: player.name === 'YASMIN' ? '#4CAF50' : '#1a1a1a' 
                      }}>
                        {player.name}
                        {player.name === 'YASMIN' && ' (You)'}
                      </Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                      <Text style={{ color: '#666', fontSize: 12, marginRight: 15 }}>
                        ⭐ {player.points} pts
                      </Text>
                      <Text style={{ color: '#666', fontSize: 12 }}>
                        🌱 {player.carbonSaved} kg CO₂
                      </Text>
                    </View>
                  </View>
                  
                  {player.rank <= 3 && (
                    <View style={{ 
                      backgroundColor: getRankColor(player.rank),
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                      borderRadius: 8,
                    }}>
                      <Text style={{ color: 'white', fontSize: 10, fontWeight: 'bold' }}>
                        {player.rank === 1 ? 'GOLD' : player.rank === 2 ? 'SILVER' : 'BRONZE'}
                      </Text>
                    </View>
                  )}
                </View>
              ))}

              {/* Your Position */}
              <View style={{ 
                backgroundColor: '#4CAF50', 
                padding: 15, 
                borderRadius: 12, 
                marginTop: 15,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
                <View>
                  <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>Your Rank: #1</Text>
                  <Text style={{ color: 'rgba(255, 255, 255, 0.9)', fontSize: 12 }}>Keep up the great work! 🎉</Text>
                </View>
                <View style={{ alignItems: 'center' }}>
                  <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 20 }}>👑</Text>
                  <Text style={{ color: 'white', fontSize: 10 }}>TOP RANK</Text>
                </View>
              </View>
            </View>
          )}

          {activeTab === 'achievements' && (
            <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 25, borderRadius: 20 }}>
              <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: '#1a1a1a', textAlign: 'center' }}>
                Your Achievements
              </Text>

              <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                {[
                  { name: 'Eco Warrior', icon: '🌱', progress: 100, color: '#4CAF50' },
                  { name: 'Water Saver', icon: '💧', progress: 80, color: '#2196F3' },
                  { name: 'Green Commuter', icon: '🚲', progress: 60, color: '#FF9800' },
                  { name: 'Recycling Hero', icon: '♻️', progress: 90, color: '#8BC34A' },
                  { name: 'Energy Saver', icon: '⚡', progress: 70, color: '#9C27B0' },
                  { name: 'Zero Waste', icon: '🌍', progress: 50, color: '#607D8B' },
                ].map((achievement, index) => (
                  <View key={index} style={{ width: '48%', marginBottom: 15 }}>
                    <View style={{ 
                      backgroundColor: achievement.color + '20', 
                      padding: 15, 
                      borderRadius: 12,
                      alignItems: 'center',
                    }}>
                      <Text style={{ fontSize: 24, marginBottom: 8 }}>{achievement.icon}</Text>
                      <Text style={{ 
                        fontWeight: '600', 
                        color: achievement.color, 
                        textAlign: 'center',
                        fontSize: 12,
                        marginBottom: 5,
                      }}>
                        {achievement.name}
                      </Text>
                      <View style={{ 
                        width: '100%', 
                        height: 6, 
                        backgroundColor: '#f0f0f0', 
                        borderRadius: 3,
                        overflow: 'hidden',
                      }}>
                        <View style={{ 
                          height: '100%', 
                          backgroundColor: achievement.color, 
                          width: `${achievement.progress}%`,
                          borderRadius: 3,
                        }} />
                      </View>
                      <Text style={{ 
                        color: achievement.color, 
                        fontSize: 10, 
                        fontWeight: 'bold',
                        marginTop: 4,
                      }}>
                        {achievement.progress}%
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          )}
        </Animated.View>
      </ScrollView>
    </View>
  );
}