import { useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';

interface Location {
  id: string;
  name: string;
  type: 'water_station' | 'recycling' | 'e_waste' | 'bike_share';
  description: string;
  distance: string;
}

export function SustainabilityMap() {
  const [selectedType, setSelectedType] = useState<string>('all');
  
  const locations: Location[] = [
    { id: '1', name: 'Library Water Station', type: 'water_station', description: 'Free water refill station', distance: '0.2 km' },
    { id: '2', name: 'Student Center Recycling', type: 'recycling', description: 'Paper, plastic, glass bins', distance: '0.5 km' },
    { id: '3', name: 'Tech Building E-Waste', type: 'e_waste', description: 'Electronic waste disposal', distance: '0.8 km' },
    { id: '4', name: 'Campus Bike Share', type: 'bike_share', description: 'Free bike rental', distance: '0.3 km' },
    { id: '5', name: 'Dorm Water Station', type: 'water_station', description: '24/7 water refill', distance: '0.6 km' },
  ];

  const filteredLocations = selectedType === 'all' 
    ? locations 
    : locations.filter(loc => loc.type === selectedType);

  const getIcon = (type: string) => {
    switch (type) {
      case 'water_station': return '💧';
      case 'recycling': return '♻️';
      case 'e_waste': return '🔌';
      case 'bike_share': return '🚲';
      default: return '📍';
    }
  };

  const getTypeName = (type: string) => {
    switch (type) {
      case 'water_station': return 'Water Station';
      case 'recycling': return 'Recycling';
      case 'e_waste': return 'E-Waste';
      case 'bike_share': return 'Bike Share';
      default: return type;
    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Campus Sustainability Map</Text>
      
      {/* Filter Buttons */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
        <TouchableOpacity
          onPress={() => setSelectedType('all')}
          style={{
            backgroundColor: selectedType === 'all' ? '#4CAF50' : '#f0f0f0',
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 20,
            marginRight: 10
          }}
        >
          <Text style={{ color: selectedType === 'all' ? 'white' : '#333' }}>All</Text>
        </TouchableOpacity>
        {['water_station', 'recycling', 'e_waste', 'bike_share'].map((type) => (
          <TouchableOpacity
            key={type}
            onPress={() => setSelectedType(type)}
            style={{
              backgroundColor: selectedType === type ? '#4CAF50' : '#f0f0f0',
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 20,
              marginRight: 10
            }}
          >
            <Text style={{ color: selectedType === type ? 'white' : '#333' }}>
              {getTypeName(type)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Locations List */}
      <ScrollView showsVerticalScrollIndicator={false}>
        {filteredLocations.map((location) => (
          <View
            key={location.id}
            style={{
              backgroundColor: 'white',
              padding: 15,
              borderRadius: 10,
              marginBottom: 10,
              borderLeftWidth: 4,
              borderLeftColor: '#4CAF50'
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
              <Text style={{ fontSize: 20, marginRight: 10 }}>{getIcon(location.type)}</Text>
              <Text style={{ fontWeight: 'bold', flex: 1 }}>{location.name}</Text>
              <Text style={{ color: '#666' }}>{location.distance}</Text>
            </View>
            <Text style={{ color: '#666', marginBottom: 5 }}>{location.description}</Text>
            <Text style={{ color: '#4CAF50', fontSize: 12 }}>{getTypeName(location.type)}</Text>
          </View>
        ))}
      </ScrollView>

      {/* Map Placeholder */}
      <View style={{ 
        backgroundColor: '#E3F2FD', 
        height: 150, 
        borderRadius: 10, 
        justifyContent: 'center', 
        alignItems: 'center',
        marginTop: 20
      }}>
        <Text style={{ color: '#2196F3', fontWeight: 'bold' }}>🗺️ Interactive Map</Text>
        <Text style={{ color: '#666', marginTop: 5 }}>Google Maps Integration Here</Text>
      </View>
    </View>
  );
}