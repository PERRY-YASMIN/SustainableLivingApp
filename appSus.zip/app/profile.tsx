import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { Storage, defaultUser } from './utils/storage';

export default function ProfileScreen() {
  const router = useRouter();
  const [user, setUser] = useState(defaultUser);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const savedUser = await Storage.get('user');
    if (savedUser) setUser(savedUser);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'white',
        paddingTop: 60,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>Profile</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 20 }}>
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 20 }}>
          <View style={{ alignItems: 'center', marginBottom: 20 }}>
            <View style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: '#4CAF50',
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 15
            }}>
              <Ionicons name="person" size={40} color="white" />
            </View>
            <Text style={{ fontSize: 24, fontWeight: 'bold' }}>{user.name}</Text>
            <Text style={{ color: '#666', marginTop: 5 }}>Eco Warrior</Text>
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
            <View style={{ alignItems: 'center' }}>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>{user.points}</Text>
              <Text style={{ color: '#666' }}>Points</Text>
            </View>
            <View style={{ alignItems: 'center' }}>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>{user.carbonSaved}</Text>
              <Text style={{ color: '#666' }}>kg CO₂ Saved</Text>
            </View>
            <View style={{ alignItems: 'center' }}>
              <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>{user.badges.length}</Text>
              <Text style={{ color: '#666' }}>Badges</Text>
            </View>
          </View>
        </View>

        <View style={{ backgroundColor: 'white', borderRadius: 15, overflow: 'hidden' }}>
          <TouchableOpacity style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' }}>
            <Text style={{ fontSize: 16 }}>Edit Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' }}>
            <Text style={{ fontSize: 16 }}>Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' }}>
            <Text style={{ fontSize: 16 }}>Help & Support</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ padding: 20 }}>
            <Text style={{ fontSize: 16, color: 'red' }}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}