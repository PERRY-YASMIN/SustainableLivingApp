export const badges = {
  beginner: { id: 'beginner', name: 'Eco Beginner', points: 100, icon: '🌱' },
  saver: { id: 'saver', name: 'Carbon Saver', points: 500, icon: '💨' },
  champion: { id: 'champion', name: 'Eco Champion', points: 1000, icon: '🏆' },
  hero: { id: 'hero', name: 'Climate Hero', points: 2000, icon: '🦸' },
  zero_waste: { id: 'zero_waste', name: 'Zero Waste Warrior', points: 750, icon: '🚯' },
  green_commuter: { id: 'green_commuter', name: 'Green Commuter', points: 600, icon: '🚲' }
};

export const checkForNewBadges = (totalPoints: number, currentBadges: string[]) => {
  const earnedBadges = [];
  
  if (totalPoints >= badges.beginner.points && !currentBadges.includes(badges.beginner.id)) {
    earnedBadges.push(badges.beginner);
  }
  if (totalPoints >= badges.saver.points && !currentBadges.includes(badges.saver.id)) {
    earnedBadges.push(badges.saver);
  }
  if (totalPoints >= badges.champion.points && !currentBadges.includes(badges.champion.id)) {
    earnedBadges.push(badges.champion);
  }
  if (totalPoints >= badges.hero.points && !currentBadges.includes(badges.hero.id)) {
    earnedBadges.push(badges.hero);
  }
  if (totalPoints >= badges.zero_waste.points && !currentBadges.includes(badges.zero_waste.id)) {
    earnedBadges.push(badges.zero_waste);
  }
  if (totalPoints >= badges.green_commuter.points && !currentBadges.includes(badges.green_commuter.id)) {
    earnedBadges.push(badges.green_commuter);
  }
  
  return earnedBadges;
};

export const getBadgeProgress = (totalPoints: number) => {
  const allBadges = Object.values(badges).sort((a, b) => a.points - b.points);
  const nextBadge = allBadges.find(badge => badge.points > totalPoints);

  if (!nextBadge) {
    return { nextBadge: null, progress: 100 };
  }

  const previousBadge = allBadges
    .filter(badge => badge.points <= totalPoints)
    .pop();

  const rangeStart = previousBadge ? previousBadge.points : 0;
  const rangeEnd = nextBadge.points;
  const progress = ((totalPoints - rangeStart) / (rangeEnd - rangeStart)) * 100;

  return {
    nextBadge,
    progress: Math.min(100, Math.max(0, progress))
  };
};