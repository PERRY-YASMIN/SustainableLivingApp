import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { User } from './types';
import { Storage, defaultUser } from './utils/storage';

export default function RewardsScreen() {
  const router = useRouter();
  const [user, setUser] = useState<User>(defaultUser);

  // ... rest of the rewards code remains the same, just with proper typing

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const savedUser = await Storage.get('user');
    if (savedUser) setUser(savedUser);
  };

  const redeemReward = async (points: number, reward: string) => {
    if (user.points >= points) {
      const updatedUser = {
        ...user,
        points: user.points - points
      };
      setUser(updatedUser);
      await Storage.set('user', updatedUser);
      alert(`🎉 Congratulations! You redeemed: ${reward}`);
    } else {
      alert('Not enough points! Keep saving the planet! 🌍');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      {/* Custom Header with Back Button */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'white',
        paddingTop: 60,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#4CAF50' }}>Rewards</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 20 }}>
        {/* Points Summary */}
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>Your Eco Points</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="star" size={30} color="#FFD700" />
            <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#4CAF50', marginLeft: 10 }}>
              {user.points}
            </Text>
          </View>
          <Text style={{ color: '#666', textAlign: 'center', marginTop: 5 }}>
            Keep earning points through eco-friendly habits!
          </Text>
        </View>

        {/* Available Rewards */}
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15 }}>Available Rewards</Text>
          
          {/* Reward 1 */}
          <View style={{ 
            borderWidth: 2, 
            borderColor: '#4CAF50', 
            borderRadius: 10, 
            padding: 15, 
            marginBottom: 15,
            backgroundColor: '#F9F9F9'
          }}>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50', fontSize: 16 }}>☕ 50 points</Text>
            <Text style={{ marginBottom: 10, fontSize: 14 }}>Free coffee at Campus Cafe</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: user.points >= 50 ? '#4CAF50' : '#ccc',
                padding: 10, 
                borderRadius: 5 
              }}
              onPress={() => redeemReward(50, 'Free Coffee')}
              disabled={user.points < 50}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                {user.points >= 50 ? 'Redeem Now' : 'Need More Points'}
              </Text>
            </TouchableOpacity>
          </View>
          
          {/* Reward 2 */}
          <View style={{ 
            borderWidth: 2, 
            borderColor: '#4CAF50', 
            borderRadius: 10, 
            padding: 15, 
            marginBottom: 15,
            backgroundColor: '#F9F9F9'
          }}>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50', fontSize: 16 }}>💧 100 points</Text>
            <Text style={{ marginBottom: 10, fontSize: 14 }}>Eco-friendly water bottle</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: user.points >= 100 ? '#4CAF50' : '#ccc',
                padding: 10, 
                borderRadius: 5 
              }}
              onPress={() => redeemReward(100, 'Eco Water Bottle')}
              disabled={user.points < 100}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                {user.points >= 100 ? 'Redeem Now' : 'Need More Points'}
              </Text>
            </TouchableOpacity>
          </View>
          
          {/* Reward 3 */}
          <View style={{ 
            borderWidth: 2, 
            borderColor: '#4CAF50', 
            borderRadius: 10, 
            padding: 15, 
            marginBottom: 15,
            backgroundColor: '#F9F9F9'
          }}>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50', fontSize: 16 }}>📚 200 points</Text>
            <Text style={{ marginBottom: 10, fontSize: 14 }}>Campus bookstore voucher</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: user.points >= 200 ? '#4CAF50' : '#ccc',
                padding: 10, 
                borderRadius: 5 
              }}
              onPress={() => redeemReward(200, 'Bookstore Voucher')}
              disabled={user.points < 200}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                {user.points >= 200 ? 'Redeem Now' : 'Need More Points'}
              </Text>
            </TouchableOpacity>
          </View>
          
          {/* Reward 4 */}
          <View style={{ 
            borderWidth: 2, 
            borderColor: '#4CAF50', 
            borderRadius: 10, 
            padding: 15,
            backgroundColor: '#F9F9F9'
          }}>
            <Text style={{ fontWeight: 'bold', color: '#4CAF50', fontSize: 16 }}>🎁 500 points</Text>
            <Text style={{ marginBottom: 10, fontSize: 14 }}>Sustainable living starter kit</Text>
            <TouchableOpacity 
              style={{ 
                backgroundColor: user.points >= 500 ? '#4CAF50' : '#ccc',
                padding: 10, 
                borderRadius: 5 
              }}
              onPress={() => redeemReward(500, 'Sustainable Living Kit')}
              disabled={user.points < 500}
            >
              <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
                {user.points >= 500 ? 'Redeem Now' : 'Need More Points'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* How to Earn Points */}
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 15 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>How to Earn Points</Text>
          <Text style={{ color: '#666', marginBottom: 5 }}>✅ Complete daily habits (+10-15 pts)</Text>
          <Text style={{ color: '#666', marginBottom: 5 }}>✅ Join weekly challenges (+25 pts)</Text>
          <Text style={{ color: '#666', marginBottom: 5 }}>✅ Invite friends (+50 pts)</Text>
          <Text style={{ color: '#666' }}>✅ Maintain streaks (+bonus pts)</Text>
        </View>
      </ScrollView>
    </View>
  );
}