import { useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { calculateCarbonFootprint } from '../utils/carbonCalculations';

export function CarbonCalculator() {
  const [transport, setTransport] = useState('');
  const [diet, setDiet] = useState('');
  const [energy, setEnergy] = useState('');
  const [result, setResult] = useState<number | null>(null);

  const calculateFootprint = () => {
    const userData = {
      transport,
      diet,
      energy: parseFloat(energy) || 0
    };
    const carbonResult = calculateCarbonFootprint(userData);
    setResult(carbonResult);
  };

  return (
    <ScrollView style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Carbon Footprint Calculator</Text>
      
      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 8 }}>Daily Transport</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {['car', 'bus', 'bike', 'walk'].map((option) => (
            <TouchableOpacity
              key={option}
              onPress={() => setTransport(option)}
              style={{
                backgroundColor: transport === option ? '#4CAF50' : '#f0f0f0',
                padding: 12,
                borderRadius: 8,
                margin: 4,
                minWidth: 80
              }}
            >
              <Text style={{ color: transport === option ? 'white' : '#333', textAlign: 'center' }}>
                {option.charAt(0).toUpperCase() + option.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 8 }}>Diet Type</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {['meat', 'vegetarian', 'vegan'].map((option) => (
            <TouchableOpacity
              key={option}
              onPress={() => setDiet(option)}
              style={{
                backgroundColor: diet === option ? '#4CAF50' : '#f0f0f0',
                padding: 12,
                borderRadius: 8,
                margin: 4,
                minWidth: 100
              }}
            >
              <Text style={{ color: diet === option ? 'white' : '#333', textAlign: 'center' }}>
                {option.charAt(0).toUpperCase() + option.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 8 }}>Weekly Energy Usage (kWh)</Text>
        <TextInput
          value={energy}
          onChangeText={setEnergy}
          placeholder="Enter kWh usage"
          keyboardType="numeric"
          style={{
            borderWidth: 1,
            borderColor: '#ddd',
            padding: 12,
            borderRadius: 8,
            backgroundColor: 'white'
          }}
        />
      </View>

      <TouchableOpacity
        onPress={calculateFootprint}
        style={{
          backgroundColor: '#4CAF50',
          padding: 15,
          borderRadius: 10,
          alignItems: 'center',
          marginBottom: 20
        }}
      >
        <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>Calculate Footprint</Text>
      </TouchableOpacity>

      {result !== null && (
        <View style={{ backgroundColor: '#E8F5E8', padding: 15, borderRadius: 10 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#2E7D32', textAlign: 'center' }}>
            Your Carbon Footprint
          </Text>
          <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#4CAF50', textAlign: 'center', marginVertical: 10 }}>
            {result} kg CO₂
          </Text>
          <Text style={{ color: '#666', textAlign: 'center' }}>
            per week • {Math.round(result / 7)} kg daily
          </Text>
        </View>
      )}
    </ScrollView>
  );
}