import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, ScrollView, Text, TouchableOpacity, View } from 'react-native';

// Define types for our data
interface Location {
  name: string;
  floor: string;
  hours: string;
  status: string;
  distance: string;
}

interface LocationsData {
  [key: string]: Location[];
}

export default function SustainabilityMapScreen() {
  const router = useRouter();
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const locations: LocationsData = {
    recycling: [
      { name: 'Main Library', floor: 'Floor 1', hours: '24/7', status: 'Available', distance: '0.2 km' },
      { name: 'Student Center', floor: 'Near Cafeteria', hours: '6 AM - 10 PM', status: 'Available', distance: '0.5 km' },
      { name: 'Science Building', floor: 'Entrance', hours: '7 AM - 9 PM', status: 'Available', distance: '0.3 km' },
    ],
    water: [
      { name: 'Gym Refill', floor: 'Locker Room', hours: '5 AM - 11 PM', status: 'Filtered', distance: '0.4 km' },
      { name: 'Library Station', floor: 'Every Floor', hours: '24/7', status: 'Chilled', distance: '0.2 km' },
    ],
    garden: [
      { name: 'Community Garden', floor: 'Behind Student Center', hours: '6 AM - 8 PM', status: 'Open', distance: '0.6 km' },
    ],
    charging: [
      { name: 'Parking Lot A', floor: '4 stations', hours: '24/7', status: '2 Available', distance: '0.8 km' },
      { name: 'Faculty Parking', floor: '2 stations', hours: '24/7', status: '1 Available', distance: '0.9 km' },
    ],
    greenspaces: [
      { name: 'Central Park', floor: 'Study Area', hours: '5 AM - 11 PM', status: 'Quiet Zone', distance: '0.3 km' },
      { name: 'Botanical Garden', floor: 'North Campus', hours: '6 AM - 9 PM', status: 'Open', distance: '1.2 km' },
    ]
  };

  const categories = [
    { id: 'all', name: 'All', icon: 'map', color: '#4CAF50' },
    { id: 'recycling', name: 'Recycling', icon: 'reload-circle', color: '#2196F3' },
    { id: 'water', name: 'Water', icon: 'water', color: '#00BCD4' },
    { id: 'garden', name: 'Garden', icon: 'leaf', color: '#8BC34A' },
    { id: 'charging', name: 'EV Charging', icon: 'flash', color: '#FF9800' },
  ];

  const getFilteredLocations = (): Location[] => {
    if (selectedCategory === 'all') {
      return Object.values(locations).flat();
    }
    return locations[selectedCategory] || [];
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d' }}>
      {/* Header */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 20, 
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        paddingTop: 60,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
      }}>
        <TouchableOpacity onPress={() => router.back()} style={{ marginRight: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#4CAF50' }}>Campus Map</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 20 }} showsVerticalScrollIndicator={false}>
        <Animated.View style={{ 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}>
          {/* Interactive Map Preview */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Campus Overview</Text>
            
            <View style={{ 
              height: 200, 
              backgroundColor: '#E8F5E8', 
              borderRadius: 15, 
              justifyContent: 'center', 
              alignItems: 'center',
              borderWidth: 2,
              borderColor: '#4CAF50',
              marginBottom: 15,
            }}>
              <Ionicons name="map" size={50} color="#4CAF50" />
              <Text style={{ color: '#4CAF50', marginTop: 10, fontWeight: '600' }}>Interactive Campus Map</Text>
              <Text style={{ color: '#666', fontSize: 12, marginTop: 5 }}>Tap to explore in detail</Text>
            </View>

            <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
              <View style={{ alignItems: 'center' }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: '#4CAF50', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ color: 'white', fontWeight: 'bold' }}>12</Text>
                </View>
                <Text style={{ fontSize: 12, color: '#666', marginTop: 5 }}>Locations</Text>
              </View>
              <View style={{ alignItems: 'center' }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: '#2196F3', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ color: 'white', fontWeight: 'bold' }}>5</Text>
                </View>
                <Text style={{ fontSize: 12, color: '#666', marginTop: 5 }}>Categories</Text>
              </View>
              <View style={{ alignItems: 'center' }}>
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: '#FF9800', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ color: 'white', fontWeight: 'bold' }}>3</Text>
                </View>
                <Text style={{ fontSize: 12, color: '#666', marginTop: 5 }}>Near You</Text>
              </View>
            </View>
          </View>

          {/* Category Filter */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 15, borderRadius: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Filter by Category</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: 'row' }}>
                {categories.map((category) => (
                  <TouchableOpacity
                    key={category.id}
                    style={{
                      backgroundColor: selectedCategory === category.id ? category.color : '#f0f0f0',
                      paddingHorizontal: 20,
                      paddingVertical: 12,
                      borderRadius: 25,
                      marginRight: 10,
                      flexDirection: 'row',
                      alignItems: 'center',
                    }}
                    onPress={() => setSelectedCategory(category.id)}
                  >
                    <Ionicons 
                      name={category.icon as any} 
                      size={16} 
                      color={selectedCategory === category.id ? 'white' : category.color} 
                    />
                    <Text style={{ 
                      color: selectedCategory === category.id ? 'white' : category.color, 
                      fontWeight: '600', 
                      marginLeft: 5,
                      fontSize: 14,
                    }}>
                      {category.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          {/* Locations List */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20, color: '#1a1a1a' }}>
              {selectedCategory === 'all' ? 'All Sustainable Locations' : `${categories.find(c => c.id === selectedCategory)?.name} Locations`}
            </Text>

            {getFilteredLocations().map((location: Location, index: number) => (
              <TouchableOpacity
                key={index}
                style={{
                  backgroundColor: '#f8f9fa',
                  padding: 15,
                  borderRadius: 12,
                  marginBottom: 12,
                  borderLeftWidth: 4,
                  borderLeftColor: '#4CAF50',
                }}
              >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#1a1a1a', marginBottom: 5 }}>
                      {location.name}
                    </Text>
                    <Text style={{ color: '#666', fontSize: 14, marginBottom: 3 }}>📍 {location.floor}</Text>
                    <Text style={{ color: '#666', fontSize: 12, marginBottom: 3 }}>🕒 {location.hours}</Text>
                    <Text style={{ color: '#4CAF50', fontSize: 12, fontWeight: '600' }}>📏 {location.distance} away</Text>
                  </View>
                  <View style={{ 
                    backgroundColor: location.status.includes('Available') || location.status === 'Open' ? '#E8F5E8' : '#FFF3E0',
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 8,
                  }}>
                    <Text style={{ 
                      color: location.status.includes('Available') || location.status === 'Open' ? '#4CAF50' : '#FF9800',
                      fontSize: 10,
                      fontWeight: 'bold',
                    }}>
                      {location.status}
                    </Text>
                  </View>
                </View>
                
                <TouchableOpacity style={{ 
                  backgroundColor: '#4CAF50', 
                  padding: 8, 
                  borderRadius: 8, 
                  marginTop: 10,
                  alignSelf: 'flex-start',
                }}>
                  <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>Get Directions</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </View>

          {/* Campus Sustainability Stats */}
          <View style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', padding: 20, borderRadius: 20, marginTop: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#1a1a1a' }}>Campus Impact 🌍</Text>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 }}>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#4CAF50' }}>1,250</Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>Plastic Bottles Saved Today</Text>
              </View>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#2196F3' }}>850</Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>Water Refills Today</Text>
              </View>
            </View>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#FF9800' }}>42</Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>EV Charging Sessions</Text>
              </View>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#8BC34A' }}>95%</Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>Waste Recycled</Text>
              </View>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}