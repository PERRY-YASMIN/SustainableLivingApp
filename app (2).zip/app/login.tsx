import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { api } from './utils/api';

export default function LoginScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter email and password');
      return;
    }

    setLoading(true);
    try {
      const result = await api.login({ email, password });
      console.log('Login successful:', result);
      router.replace('/(tabs)');
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0f2d', padding: 20, justifyContent: 'center' }}>
      <View style={{ alignItems: 'center', marginBottom: 40 }}>
        <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#4CAF50', marginBottom: 10 }}>EcoCampus</Text>
        <Text style={{ color: 'white', fontSize: 16 }}>Welcome Back!</Text>
      </View>

      <View style={{ backgroundColor: 'rgba(255,255,255,0.95)', padding: 25, borderRadius: 20 }}>
        <TextInput
          style={{
            backgroundColor: 'white',
            padding: 15,
            borderRadius: 10,
            marginBottom: 15,
            borderWidth: 1,
            borderColor: '#ddd',
          }}
          placeholder="Email Address"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <TextInput
          style={{
            backgroundColor: 'white',
            padding: 15,
            borderRadius: 10,
            marginBottom: 25,
            borderWidth: 1,
            borderColor: '#ddd',
          }}
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity 
          onPress={handleLogin}
          disabled={loading}
          style={{
            backgroundColor: loading ? '#cccccc' : '#4CAF50',
            padding: 15,
            borderRadius: 10,
            alignItems: 'center',
          }}
        >
          <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>
            {loading ? 'Signing In...' : 'Sign In'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          onPress={() => router.push('/signup')}
          style={{ alignItems: 'center', marginTop: 15 }}
        >
          <Text style={{ color: '#4CAF50', fontWeight: '500' }}>
            Don't have an account? Sign Up
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}